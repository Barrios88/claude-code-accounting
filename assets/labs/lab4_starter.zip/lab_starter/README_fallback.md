# Fallback Sample Data — Module 4 Lab

## What this is

`fallback_panel.parquet` and `fallback_panel.csv` are built entirely from the
**SEC Financial Statement Data Sets** — a public dataset published quarterly by
the SEC's Division of Economic and Risk Analysis (DERA) at:

> https://www.sec.gov/data-research/sec-markets-data/financial-statement-data-sets

No WRDS account, no credentials, no institutional access of any kind is required
to recreate this data.

## Why it exists

In Module 4, the lab exercises connect to WRDS via the `wrds-mcp` server and a
persistent Duo tunnel. If your Duo approval times out, your WRDS account is
inactive, or the tunnel fails during class, you can substitute this fallback
dataset and complete every pandas / DuckDB / Stata exercise in the lab notebook
without interruption.

**The same analytical steps apply.** The columns are named to match the
funda-like panel you would pull from Compustat:

| Column | Meaning | Analogous Compustat variable |
|---|---|---|
| `firm_id` | 10-digit CIK (zero-padded) | Stands in for `gvkey` |
| `company_name` | Registrant name | `conm` |
| `period` | Fiscal period end (YYYYMMDD) | `datadate` |
| `fp` | Fiscal period label | `fp` |
| `at` | Total assets (USD) | `at` |
| `sale` | Revenue (USD) | `sale` |
| `ni` | Net income (USD) | `ni` |

## What it covers

- **Source:** SEC DERA Financial Statement Data Sets (quarterly zip, `sub.txt` + `num.txt`)
- **Scope:** One quarter of 10-K annual filings (the quarter specified when the script was run). Only each filer's own current-year values are kept: prior-year comparatives, segment rows, and co-registrant rows are dropped.
- **Tags extracted:** `Assets`, `Revenues`, `RevenueFromContractWithCustomerExcludingAssessedTax`, `NetIncomeLoss`
- **Row limit:** ≤ 5,000 firm-year observations (kept small for class use)

## Reproducibility

Rebuild from scratch at any time:

```bash
pip install requests pandas pyarrow

# SEC requires a User-Agent with your name and email on every request:
export SEC_USER_AGENT="Your Name your.email@yale.edu"

# Download a specific quarter (requires internet access):
python build_fallback_sample.py --quarter 2023q4 --out-dir .

# Validate the script logic without downloading:
python build_fallback_sample.py --dry-run
```

The script requires no WRDS credentials and pulls only from SEC.gov's public HTTPS endpoint.

## Data quality notes

- This is **not** Compustat. It reflects XBRL tags as filed, which vary by
  company and period. Revenue in particular may be missing or filed under a
  different tag for some firms.
- `firm_id` (CIK) is **not** `gvkey`. You cannot directly join to CRSP or
  Compustat using this column without a CIK–gvkey crosswalk (not included here).
- The dataset is suitable for practicing pandas aggregation, DuckDB SQL,
  and Stata data steps — the goal is mechanics, not publishable empirics.

## License / attribution

The underlying data is U.S. government public domain (SEC EDGAR). The build
script is part of the Module 4 lab materials for "Claude Code for Accounting
Research" (John Barrios, Yale School of Management).
