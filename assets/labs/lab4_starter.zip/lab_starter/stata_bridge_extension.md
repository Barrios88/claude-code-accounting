# Stata Bridge Extension

The export rule and the two-language check apply on either track. The regression in Step 3
needs the live `funda` pull: the fallback panel has no SIC code, no debt item, and essentially
one fiscal year. On the fallback track, regress `roa` (`ni / at`) on `log(at)` with no fixed
effects and heteroskedasticity-robust errors (`vce(robust)`; with about one row per firm,
clustering by firm would amount to the same thing), and use that model in Step 5. The whole
extension is optional: it is not required for this module's core lab.

## Rule: export only the analysis-ready table

**Never export a full `funda` pull, or the full fallback panel, to `.dta`.** Export only the
filtered table, with only the columns you built for your analysis. This is the "no
`SELECT *`" rule applied to the last step of the pipeline instead of the first. A full
Compustat pull is too large for Stata to handle comfortably, and exporting it undoes the
filtering you already did.

## Step 1 — Build the analysis-ready table in DuckDB

Starting from your Parquet-backed DuckDB database, create a narrow table with only the
variables your regression needs:

```sql
CREATE TABLE firm_year AS
SELECT gvkey, fyear, sich, lev, roa
FROM analysis_ready
WHERE lev IS NOT NULL AND roa IS NOT NULL;
```

(`sich` is `funda`'s historical SIC code; add it to your pull if you left it out. On the
fallback track, select `firm_id`, `at`, and `roa` instead.)

## Step 2 — Export to `.dta`

From Python, using `pandas` and `pyreadstat` (or pandas' built-in `.to_stata()`):

```python
import duckdb

con = duckdb.connect("lab4.duckdb")   # the database file you built firm_year in
df = con.sql("SELECT gvkey, fyear, sich, lev, roa FROM firm_year").df()
df.to_stata("firm_year.dta", write_index=False)
```

(Fallback track: `SELECT firm_id, at, roa FROM firm_year`.)

Confirm the exported file contains only the narrow table. Open it and check the variable
list before you move to Stata. If you see more than a handful of columns, you exported the
wrong table.

## Step 3 — Run the regression in Stata (live track)

Save the code below as `firm_year_regression.do` and run it. It runs a leverage–ROA regression with fiscal-year
and two-digit-SIC fixed effects:

```stata
use "firm_year.dta", clear

* gvkey is a string; Stata needs a numeric firm id for clustering
egen firm = group(gvkey)

* Two-digit SIC group for fixed effects
gen sic2 = floor(sich / 100)

* Labels — pull these directly from your metadata table, don't re-guess them
label variable lev  "Book leverage (long-term debt / total assets)"
label variable roa  "Return on assets (net income / total assets)"
label variable sic2 "Two-digit SIC industry group"

* Leverage-ROA regression with fyear and SIC2 fixed effects
reghdfe roa lev, absorb(fyear sic2) vce(cluster firm)

* If reghdfe is unavailable, the equivalent with built-in commands
* (point estimates match; standard errors can differ, see Step 5):
* areg roa lev i.fyear, absorb(sic2) vce(cluster firm)
```

## Step 4 — Connect labels to your metadata table

Take the `label variable` lines above directly from the descriptions you already wrote in
your `metadata` table. Do not write a new description of the same variable that might not
match. If your metadata table says `lev` is "book leverage, long-term debt over total
assets," the Stata label should say exactly that. This carries the context-engineering habit
from the module page one step further: the same documentation goes with the variable into
Stata that it had in DuckDB.

## Step 5 — Two-language check (Python vs. Stata)

This step comes from this module's notes. In a fresh Claude session, give Claude only a
written description of the model: the outcome, the regressors, the two sets of fixed effects,
and how standard errors are clustered. Ask for a Python version that reads the same `.dta`
file. Don't show it the `.do` file.

Compare the leverage coefficient from the two runs to six decimal places and paste both
numbers into your notes. If the standard errors differ, find the default that explains the
gap and write it down.

## Verify

- [ ] Only the narrow, analysis-ready table was exported — never the full pull
- [ ] Every regression variable has a `label variable` line matching its metadata-table description
- [ ] The regression runs and reports fyear/SIC2 fixed effects as specified
- [ ] No WRDS-derived `.dta` file exists outside your project's local data directory
- [ ] Two-language check done: the Stata and Python leverage coefficients are both pasted into
      your notes, compared to six decimal places, and any standard-error gap is explained by
      a named default

## Another extension (either track): fan it out with sub-agents

The lab page has a second, separate extension. It answers the question from the Module 2
exit ticket. Ask Claude to split a profile of your landed Parquet file across parallel
sub-agents, one per block of fiscal years (three or four blocks is enough). The fallback panel
covers essentially one fiscal year, so on that track split it into three blocks of `firm_id`. Each sub-agent
reports row counts, the share of missing `at` and `sale`, and any duplicate firm-year pairs,
and writes those numbers to its own file in a `checks/` folder. In your prompt, tell each
sub-agent to read your metadata table before it queries anything. Then:

- Ask the main session to compare the files and flag the block that looks least like the
  others.
- Open one of the `checks/` files yourself and confirm one number in it against a DuckDB
  query you run directly.
- Type `/context` before and after the exercise to see how much of your main session's
  context it used. Compare that with what the same profile would have cost run in the main
  session.
