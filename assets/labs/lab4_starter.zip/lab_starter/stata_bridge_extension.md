# Stata Bridge Extension (either track)

This extension is available whether you completed the live or fallback track — the export
and regression steps are identical either way. It is not required to complete today's core
lab; treat it as a stretch goal or homework if lab time runs out.

## Rule: export only the analysis-ready table

**Never export a full `funda` pull, or the full fallback panel, to `.dta`.** Export only the
filtered, column-limited table you actually built for your analysis — the same discipline as
"no `SELECT *`," applied to the last step of the pipeline instead of the first. A full
Compustat pull is too large for Stata to handle comfortably and defeats the point of the
filtering you already did.

## Step 1 — Build the analysis-ready table in DuckDB

Starting from your Parquet-backed DuckDB database, create a narrow table with only the
variables your regression needs:

```sql
CREATE TABLE firm_year AS
SELECT gvkey, fyear, sic, lev, roa
FROM analysis_ready
WHERE lev IS NOT NULL AND roa IS NOT NULL;
```

(Substitute `firm_id`, `period` for `gvkey`, `fyear` if you're on the fallback track — same
structure, different column names.)

## Step 2 — Export to `.dta`

From Python, using `pandas` and `pyreadstat` (or pandas' built-in `.to_stata()`):

```python
import duckdb

df = duckdb.sql("SELECT * FROM firm_year").df()
df.to_stata("firm_year.dta", write_index=False)
```

Confirm the exported file contains only the narrow table — open it and check the variable
list before moving to Stata. If you see more than a handful of columns, you exported the
wrong table.

## Step 3 — Run the provided `.do` file

The starter pack's `firm_year_regression.do` runs a leverage–ROA regression with fiscal-year
and two-digit-SIC fixed effects:

```stata
use "firm_year.dta", clear

* Two-digit SIC group for fixed effects
gen sic2 = floor(sic / 100)

* Labels — pull these directly from your metadata table, don't re-guess them
label variable lev  "Book leverage (long-term debt / total assets)"
label variable roa  "Return on assets (net income / total assets)"
label variable sic2 "Two-digit SIC industry group"

* Leverage-ROA regression with fyear and SIC2 fixed effects
reghdfe roa lev, absorb(fyear sic2) vce(cluster gvkey)

* If reghdfe is unavailable, the equivalent with built-in commands:
* xtset gvkey fyear
* areg roa lev i.fyear, absorb(sic2) cluster(gvkey)
```

## Step 4 — Connect labels to your metadata table

The `label variable` lines above should come directly from the descriptions you already wrote
in your `metadata` table — not a fresh, possibly inconsistent, restatement of the same
variable. If your metadata table says `lev` is "book leverage, long-term debt over total
assets," the Stata label should say exactly that. This is the same context-engineering habit
from the module page, carried one step further: the documentation follows the variable
wherever it goes, DuckDB or Stata.

## Verify

- [ ] Only the narrow, analysis-ready table was exported — never the full pull
- [ ] Every regression variable has a `label variable` line matching its metadata-table description
- [ ] The regression runs and reports fyear/SIC2 fixed effects as specified
- [ ] No WRDS-derived `.dta` file exists outside your project's local data directory
