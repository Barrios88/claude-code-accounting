# Module 4 Iron Law Checklist

Fill this in while you build your query, before you run it. If you can't check a box, fix
the query first.

## Compustat — `comp.funda` / `comp.fundq`

All four filters below are required. A query missing even one still runs without errors and
returns rows that look reasonable, which is why the omission is easy to miss.

- [ ] `indfmt = 'INDL'` present — excludes financial-format reporters from an industrial sample
- [ ] `datafmt = 'STD'` present — excludes as-reported figures that don't mean the same thing across firms
- [ ] `popsrc = 'D'` present — restricts to the domestic population source
- [ ] `consol = 'C'` present — excludes unconsolidated subsidiary rows that would otherwise duplicate their parent
- [ ] Date range explicitly specified (e.g., `datadate BETWEEN %s AND %s`)
- [ ] No `SELECT *` anywhere — name every column you pull

Paste your actual `WHERE` clause here once it passes every box above:

```sql

```

## CRSP — manual filters (no tool in this stack applies these for you)

**CRSP filters are not automatic.** That includes the `wrds_get_crsp_returns` helper, which
joins returns to names on permno and a date range and does nothing more. Apply the following
yourself, every time, as a filter step after the query:

- [ ] `sharetype == 'NS'`
- [ ] `securitytype == 'EQTY'`
- [ ] `securitysubtype == 'COM'`
- [ ] `usincflg == 'Y'`
- [ ] `issuertype` in `['ACOR', 'CORP']`
- [ ] Date range specified

## CRSP–Compustat Link (if your panel needs it)

- [ ] Joined via `crsp.ccmxpf_linkhist` (or the `wrds_merge_crsp_compustat` helper)
- [ ] `linktype IN ('LU', 'LC')` and `linkprim IN ('P', 'C')`
- [ ] `linkdt` / `linkenddt` bounds respected — no links outside the valid date range
- [ ] Row count after the merge checked for an unexpected jump (duplicate keys on one side)

## Inspection — required after every query, before you report anything

- [ ] Row count compared with the number you expected *before* you ran the query
- [ ] `.head()` or `.sample()` reviewed — actual values, not just column names
- [ ] Null check run on every column you plan to use
- [ ] Date range (`fyear` or `datadate` min/max) checked against your requested window
- [ ] One benchmark value checked against a source Claude did not touch

If any box above is unchecked when you report a result, say so. Do not assume the result is
fine because the query ran without an error. A query that runs is not the same as a query
that is correct.
