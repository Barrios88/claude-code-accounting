# Module 4 Iron Law Checklist

Fill this in as you build your query — before you execute it, not after. If you can't check
a box, fix the query first.

## Compustat — `comp.funda` / `comp.fundq`

All four filters below are mandatory. Missing even one produces a query that runs cleanly
and returns rows that look reasonable — that's exactly what makes the omission dangerous.

- [ ] `indfmt = 'INDL'` present — excludes financial-format reporters from an industrial sample
- [ ] `datafmt = 'STD'` present — excludes as-reported figures that don't mean the same thing across firms
- [ ] `popsrc = 'D'` present — restricts to the domestic population source
- [ ] `consol = 'C'` present — excludes unconsolidated subsidiary rows that would otherwise duplicate their parent
- [ ] Date range explicitly specified (e.g., `datadate BETWEEN %s AND %s`)
- [ ] No `SELECT *` anywhere — every column you pull is named on purpose

Paste your actual `WHERE` clause here once it passes every box above:

```sql

```

## CRSP — manual filters (no tool in this stack applies these for you)

**Locked fact: CRSP filters are not automatic**, including inside the `wrds_get_crsp_returns`
helper — that helper joins returns to names on permno and a date range and stops there.
Apply the following yourself, every time, as a post-query filter step:

- [ ] `sharetype == 'NS'`
- [ ] `securitytype == 'EQTY'`
- [ ] `securitysubtype == 'COM'`
- [ ] `usincflg == 'Y'`
- [ ] `issuertype` in `['ACOR', 'CORP']`
- [ ] Date range specified

## CRSP–Compustat Link (if your panel needs it)

- [ ] Joined via `crsp.ccmxpf_linkhist` (or the `wrds_merge_crsp_compustat` helper)
- [ ] `linktype IN ('LU', 'LC')` and `linkprim IN ('P', 'C')`
- [ ] `linkdt` / `linkenddt` bounds respected — no linking outside the valid date range
- [ ] Row count after the merge checked for an unexpected explosion (duplicate keys on one side)

## Inspection — mandatory after every query, before you report anything

- [ ] Row count checked against what you expected *before* running the query, not just glanced at
- [ ] `.head()` or `.sample()` reviewed — actual values, not just column names
- [ ] Null check run on every column you plan to use
- [ ] Date range (`fyear` or `datadate` min/max) checked against your requested window
- [ ] One benchmark value checked against a source Claude did not touch

If any box above is unchecked when you go to report a result, the honest move is to say so —
not to assume it's probably fine because the query ran without an error. "It ran" and "it's
correct" are two different claims.
