# Metadata Table Template

Fill in at least 8 rows before you finish the lab's inspection step. A fresh Claude session,
or a coauthor who never saw your original prompts, reads this table to understand your data
from scratch. Load it into DuckDB as a table named `metadata` (or `compustat_metadata` on the
live track) so you can query it with plain SQL instead of only reading it as a markdown file.

Columns:

- **varname** — the exact column name as it appears in your extract
- **label** — a plain-language description a coauthor outside your specialty could understand
- **units** — the unit of measurement, or "categorical" / "identifier" if there isn't one
- **screening note** — anything a user needs to know before using this variable (valid
  range, known missingness pattern, a filter to apply when this variable is the focus of an
  analysis)

| varname | label | units | screening note |
|---|---|---|---|
| gvkey |  |  |  |
| fyear |  |  |  |
| sale |  |  |  |
| at |  |  |  |
| dltt |  |  |  |
| ni |  |  |  |
| csho |  |  |  |
| prcc_f |  |  |  |

Add rows below for anything else your panel uses:

| varname | label | units | screening note |
|---|---|---|---|
|  |  |  |  |
|  |  |  |  |

## Fallback-track column mapping

If you're on the fallback track, your columns have different names. Document the mapping
explicitly. Do not treat the fallback panel as Compustat with different labels:

| varname | label | units | screening note |
|---|---|---|---|
| firm_id |  | identifier | stands in for `gvkey`; is a zero-padded CIK, not a gvkey — cannot join to CRSP/Compustat without a crosswalk |
| company_name |  |  |  |
| period |  |  | stands in for `datadate` |
| at |  |  |  |
| sale |  |  | XBRL tag coverage is inconsistent across filers — note which tag(s) you used |
| ni |  |  |  |

## Verify this table works before moving on

Once the table is loaded into DuckDB, close your Claude Code session entirely, open a new
one, and orient it with nothing but:

```sql
SELECT * FROM metadata;
```

If the new session can describe your variables correctly (units, what to watch out for)
from that query alone, the table works. If it can't, the table is missing something the
previous session treated as obvious.
