# Metadata Table Template

Fill in at least 8 rows before the lab's inspection step is complete. This table is what a
fresh Claude session — or a coauthor who never saw your original prompts — reads to
understand your data cold. Load it into DuckDB as a table named `metadata` (or
`compustat_metadata` on the live track) so it's queryable with plain SQL, not just readable
as a markdown file.

Columns:

- **varname** — the exact column name as it appears in your extract
- **label** — a plain-language description a non-specialist coauthor could read and understand
- **units** — the unit of measurement, or "categorical" / "identifier" if there isn't one
- **screening note** — anything a user of this variable needs to know before using it (valid
  range, known missingness pattern, a filter that should be applied when this variable is the
  focus of an analysis)

| varname | label | units | screening note |
|---|---|---|---|
| gvkey |  |  |  |
| fyear |  |  |  |
| sale |  |  |  |
| at |  |  |  |
| dltt |  |  |  |
| ni |  |  |  |
| csho |  |  |  |
| prcc_f |  |  |  |

Add rows below for anything else your panel uses:

| varname | label | units | screening note |
|---|---|---|---|
|  |  |  |  |
|  |  |  |  |

## Fallback-track column mapping

If you're on the fallback track, your columns are named differently — document the mapping
explicitly rather than pretending the fallback panel is Compustat with different labels:

| varname | label | units | screening note |
|---|---|---|---|
| firm_id |  | identifier | stands in for `gvkey`; is a zero-padded CIK, not a gvkey — cannot join to CRSP/Compustat without a crosswalk |
| company_name |  |  |  |
| period |  |  | stands in for `datadate` |
| at |  |  |  |
| sale |  |  | XBRL tag coverage is inconsistent across filers — note which tag(s) you used |
| ni |  |  |  |

## Verify this table works before moving on

Once loaded into DuckDB, close your Claude Code session entirely, open a brand-new one, and
orient it with nothing but:

```sql
SELECT * FROM metadata;
```

If the fresh session can correctly describe your variables — units, what to watch out for —
from that query alone, the table is doing its job. If it can't, the table is missing
something the last session assumed was obvious.
