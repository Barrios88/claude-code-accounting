# Module 4 Verify Checklist

Self-graded, pass/fail, as in every other module. Work through every line before you call
the lab complete. When the course runs with a group, the instructor spot-checks a sample of
these rather than grading each box. Either way, what counts is your own honest sign-off.

- [ ] `~/.wrds-mcp.env` lives outside the project (or, if a copy is inside, `git check-ignore`
      confirms it is ignored), and after sourcing it, this command run from the project folder
      returns nothing:

      ```bash
      grep -rIl --exclude-dir=.git -F "$WRDS_PASSWORD" .
      ```

      If it lists every file, `$WRDS_PASSWORD` is empty: source `~/.wrds-mcp.env` and run it again.
      Never type the password itself on the command line, where it lands in your shell history.
      (Live track: this must actually be true. Fallback track: this passes automatically
      because no WRDS credentials are involved.)

- [ ] All four iron-law filters are present in the query. Paste the `WHERE` clause here.
      (Fallback track: there is no `WHERE` clause. Paste the list of XBRL tags you used and
      why.)

      ```sql

      ```

- [ ] Four inspection checks written down with actual numbers, not impressions, plus one benchmark firm:

      Row count: _______________  Expected: _______________

      fyear / period min–max: _______________________________

      Sample eyeball — anything unexpected: __________________

      Null shares in the columns you use: ______________________

      Benchmark firm checked against: _________________________
      Value from Claude's pull: _____  Value from independent source: _____

- [ ] `analysis_ready` table built (`lev` and `roa` on the live track, `roa` on the fallback
      track), and the metadata table is queryable in DuckDB (`SELECT * FROM compustat_metadata` on the live track, or `SELECT * FROM metadata` on the fallback track, returns results), with
      at least 8 variables documented — units and one screening note each.

- [ ] Explicit variable list in every query against a WRDS table or your raw extract. No
      `SELECT *` there. (`SELECT * FROM metadata` on your own small tables is fine.)

- [ ] No WRDS-derived file exists anywhere outside `~/wrds_data` or your project's data
      directory. Nothing WRDS-derived is committed to git. Check with `git status` and
      `git log --stat` if you're unsure what has already been committed.

- [ ] **Tunnel torn down** (live track only). Run `tunnel_down.sh`, then confirm with
      `tunnel_status.sh` that the tunnel is closed. Don't assume it closed. This is the last
      item on the list on purpose. People often skip it, so you check it last.

## Extensions

The two optional extensions on the lab page (the Stata bridge with its two-language check,
and the sub-agent fan-out) are not part of this checklist. Their steps and checks are in
`stata_bridge_extension.md`.

## If any box is unchecked

Don't erase the box. Note what is blocking it in your own notes or on your exit ticket. An
honestly unchecked box is more useful than one checked out of habit. That matters most for
the iron-law and teardown boxes. It is better to catch those problems now than three weeks
into the pull for your own dissertation.
