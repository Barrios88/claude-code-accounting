# Day 4 Verify Checklist

Self-graded, pass/fail. Work through every line before you consider the lab complete. The
instructor will spot-check a sample of these, not grade each box individually — the point is
your own honest sign-off, same as every other day this week.

- [ ] `.env` exists, is gitignored, and `grep -r` for your WRDS password over the entire
      project returns nothing.

      (Live track: this must actually be true. Fallback track: trivially true since there are
      no WRDS credentials involved — check anyway; the habit is what matters.)

- [ ] All four iron-law filters are present in the query. Paste the `WHERE` clause here:

      ```sql

      ```

- [ ] Four inspection checks written down with actual numbers, not impressions:

      Row count: _______________  Expected: _______________

      fyear / period min–max: _______________________________

      Sample eyeball — anything unexpected: __________________

      Benchmark firm checked against: _________________________
      Value from Claude's pull: _____  Value from independent source: _____

- [ ] Metadata table is queryable in DuckDB (`SELECT * FROM metadata` returns results), with
      at least 8 variables documented — units and one screening note each.

- [ ] Explicit variable list in every query this session. No `SELECT *` anywhere in any
      script you wrote today.

- [ ] **Tunnel torn down** (live track only). Confirmed with `tunnel_status.sh`, not just
      assumed after running `tunnel_down.sh`. This is the last box on this checklist on
      purpose — it's the step everyone skips, so it's the step you check last, deliberately.

- [ ] No WRDS-derived file exists anywhere outside `~/wrds_data` or your project's data
      directory. Nothing WRDS-derived is committed to git — check with `git status` and
      `git log --stat` if you're unsure what's already been committed.

## If any box is unchecked

Don't erase the box — note what's blocking it and bring it to the debrief, or flag it on your
exit ticket. An honestly unchecked box is more useful to the instructor than one checked out
of habit, and it is especially useful here: an unchecked iron-law or teardown box is exactly
the kind of thing worth catching in class rather than three weeks into your own dissertation
pull.
