# Module 4 Verify Checklist

Self-graded, pass/fail, as in every other module. Work through every line before you call
the lab complete. The instructor will spot-check a sample of these rather than grade each box
individually. What counts is your own honest sign-off.

- [ ] `.env` exists, is gitignored, and `grep -r` for your WRDS password over the entire
      project returns nothing.

      (Live track: this must actually be true. Fallback track: this passes automatically
      because no WRDS credentials are involved. Check anyway to build the habit.)

- [ ] All four iron-law filters are present in the query. Paste the `WHERE` clause here.
      (Fallback track: there is no `WHERE` clause. Paste the list of XBRL tags you used and
      why.)

      ```sql

      ```

- [ ] Four inspection checks written down with actual numbers, not impressions:

      Row count: _______________  Expected: _______________

      fyear / period min–max: _______________________________

      Sample eyeball — anything unexpected: __________________

      Benchmark firm checked against: _________________________
      Value from Claude's pull: _____  Value from independent source: _____

- [ ] Metadata table is queryable in DuckDB (`SELECT * FROM metadata` returns results), with
      at least 8 variables documented — units and one screening note each.

- [ ] Explicit variable list in every query this session. No `SELECT *` anywhere in any
      script you wrote in this module.

- [ ] No WRDS-derived file exists anywhere outside `~/wrds_data` or your project's data
      directory. Nothing WRDS-derived is committed to git. Check with `git status` and
      `git log --stat` if you're unsure what has already been committed.

- [ ] **Tunnel torn down** (live track only). Run `tunnel_down.sh`, then confirm with
      `tunnel_status.sh` that the tunnel is closed. Don't assume it closed. This is the last
      item on the list on purpose. People often skip it, so you check it last.

## Extensions

The two optional extensions on the lab page (the Stata bridge with its two-language check,
and the sub-agent fan-out) are not part of this checklist. Their steps and checks are in
`stata_bridge_extension.md`.

## If any box is unchecked

Don't erase the box. Note what is blocking it and bring it to the debrief, or flag it on your
exit ticket. An honestly unchecked box is more useful to the instructor than one checked out
of habit. That matters most for the iron-law and teardown boxes. It is better to catch those
problems in class than three weeks into the pull for your own dissertation.
