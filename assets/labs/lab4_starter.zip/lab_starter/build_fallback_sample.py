"""
build_fallback_sample.py
------------------------
Downloads one quarter of the SEC Financial Statement Data Sets
(https://www.sec.gov/dera/data/financial-statement-data-sets),
extracts sub.txt and num.txt, and produces a small firm-year-like
panel with funda-style columns saved as:

    fallback_panel.parquet
    fallback_panel.csv

100% public SEC data. No WRDS credentials required.

Usage
-----
    # Download a real quarter (requires internet):
    python build_fallback_sample.py --quarter 2023q4

    # Dry-run (validates logic on a tiny synthetic frame, no download):
    python build_fallback_sample.py --dry-run

    # Specify output directory:
    python build_fallback_sample.py --quarter 2023q4 --out-dir ./data

Dependencies
------------
    pip install requests pandas pyarrow
"""

import argparse
import io
import sys
import zipfile
from pathlib import Path

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

# ---------------------------------------------------------------------------
# SEC DERA Financial Statement Data Sets
# URL pattern: https://www.sec.gov/Archives/edgar/full-index/...
# Preferred pattern (DERA direct):
#   https://www.sec.gov/dera/data/financial-statement-data-sets/{YYYY}q{Q}.zip
#
# Example: https://www.sec.gov/dera/data/financial-statement-data-sets/2023q4.zip
# ---------------------------------------------------------------------------

SEC_URL_TEMPLATE = (
    "https://www.sec.gov/files/dera/data/financial-statement-data-sets/{quarter}.zip"
)

# User-Agent is REQUIRED by SEC EDGAR fair-access policy: it must name you and
# give a contact email. Set it with the SEC_USER_AGENT environment variable,
# e.g.  export SEC_USER_AGENT="Jane Doe jane.doe@yale.edu"
import os
USER_AGENT = os.environ.get("SEC_USER_AGENT", "")

# Financial statement tags we want for the funda-like panel.
TARGET_TAGS = {
    "Assets":                             "at",        # total assets
    "Revenues":                           "sale",      # revenue (broad tag)
    "RevenueFromContractWithCustomerExcludingAssessedTax": "sale_asc606",  # ASC 606
    "NetIncomeLoss":                      "ni",        # net income
}

# Columns in the output panel.
OUTPUT_COLUMNS = [
    "firm_id",      # CIK (padded 10-digit string, stands in for gvkey)
    "company_name", # company name from sub.txt
    "period",       # fiscal period end (YYYYMMDD)
    "fp",           # fiscal period label (FY, Q1, Q2, Q3, Q4)
    "at",           # total assets (USD)
    "sale",         # revenue (USD) — uses Revenues if available, else ASC-606 tag
    "ni",           # net income (USD)
]

MAX_OUTPUT_ROWS = 5_000   # keep the file small for class use


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _resolve_revenue(df: pd.DataFrame) -> pd.Series:
    """Return a revenue series, preferring 'sale' over 'sale_asc606'."""
    if "sale" in df.columns and "sale_asc606" in df.columns:
        return df["sale"].fillna(df["sale_asc606"])
    if "sale" in df.columns:
        return df["sale"]
    if "sale_asc606" in df.columns:
        return df["sale_asc606"]
    return pd.Series(pd.NA, index=df.index, dtype="Float64")


def _shape_panel(sub: pd.DataFrame, num: pd.DataFrame) -> pd.DataFrame:
    """
    Pivot num.txt tags into columns and join with sub.txt metadata.

    sub.txt key columns: adsh, cik, name, period, fp, form, fy
    num.txt key columns: adsh, tag, ddate, qtrs, uom, value
    """
    # Keep only the tags we care about.
    num = num[num["tag"].isin(TARGET_TAGS)].copy()

    # Rename tag → short name.
    num["col"] = num["tag"].map(TARGET_TAGS)

    # Keep only the filer's own current-year values. A 10-K also reports prior
    # years (comparatives), segment breakdowns, and co-registrant figures; taking
    # the first matching row would mix those in. So keep rows that:
    #   - are dated at the filing's own fiscal period end (ddate == sub.period),
    #   - are instants (qtrs == 0) for assets and full years (qtrs == 4) for flows,
    #   - have no segment or co-registrant qualifier, and are in USD.
    if "period" in sub.columns:
        per = sub[["adsh", "period"]].copy()
        per["period"] = pd.to_numeric(per["period"], errors="coerce")
        num = num.merge(per, on="adsh", how="inner")
        num["ddate"] = pd.to_numeric(num["ddate"], errors="coerce")
        num = num[num["ddate"] == num["period"]]
    num["qtrs"] = pd.to_numeric(num["qtrs"], errors="coerce")
    is_stock = num["col"] == "at"
    num = num[(is_stock & (num["qtrs"] == 0)) | (~is_stock & (num["qtrs"] == 4))]
    for qual in ["segments", "coreg"]:
        if qual in num.columns:
            num = num[num[qual].isna() | (num[qual].astype(str).str.strip() == "")]
    if "uom" in num.columns:
        num = num[num["uom"] == "USD"]
    num = num.copy()

    # Pivot: one row per (adsh, ddate), columns = at / sale / sale_asc606 / ni.
    pivoted = (
        num.groupby(["adsh", "col"])["value"]
        .first()   # first occurrence if duplicates
        .unstack("col")
        .reset_index()
    )

    # Ensure numeric.
    for c in ["at", "sale", "sale_asc606", "ni"]:
        if c in pivoted.columns:
            pivoted[c] = pd.to_numeric(pivoted[c], errors="coerce")

    # Resolve revenue.
    pivoted["sale"] = _resolve_revenue(pivoted)

    # Keep only at / sale / ni (drop the intermediate sale_asc606).
    for drop_col in ["sale_asc606"]:
        if drop_col in pivoted.columns:
            pivoted = pivoted.drop(columns=[drop_col])

    # Join with sub.
    keep_sub = ["adsh", "cik", "name", "period", "fp", "form"]
    keep_sub = [c for c in keep_sub if c in sub.columns]
    merged = pivoted.merge(sub[keep_sub], on="adsh", how="left")

    # Build firm_id: zero-padded 10-digit CIK.
    merged["firm_id"] = merged["cik"].astype(str).str.zfill(10)

    # Keep annual filings only (10-K, 10-K405, 10-KSB) for a funda-like panel.
    if "form" in merged.columns:
        annual_mask = merged["form"].str.upper().str.startswith("10-K")
        merged = merged[annual_mask].copy()

    # Rename / select.
    merged = merged.rename(columns={"name": "company_name", "period": "period"})
    if "period" in merged.columns:
        merged["period"] = pd.to_numeric(merged["period"], errors="coerce").astype("Int64")

    out_cols = [c for c in OUTPUT_COLUMNS if c in merged.columns]
    merged = merged[out_cols].copy()

    # Drop rows where all financial columns are null.
    fin_cols = [c for c in ["at", "sale", "ni"] if c in merged.columns]
    if fin_cols:
        merged = merged.dropna(subset=fin_cols, how="all")

    return merged.head(MAX_OUTPUT_ROWS)


def _synthetic_frame() -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return tiny synthetic sub / num frames for --dry-run validation."""
    sub = pd.DataFrame({
        "adsh":   ["0000000001-23-000001", "0000000002-23-000002",
                   "0000000003-23-000003"],
        "cik":    [1, 2, 3],
        "name":   ["Alpha Corp", "Beta Inc", "Gamma Ltd"],
        "period": [20231231, 20231231, 20230630],
        "fp":     ["FY", "FY", "FY"],
        "form":   ["10-K", "10-K", "10-K"],
    })
    num = pd.DataFrame({
        "adsh":  ["0000000001-23-000001"] * 3 +
                 ["0000000002-23-000002"] * 3 +
                 ["0000000003-23-000003"] * 2,
        "tag":   ["Assets", "Revenues", "NetIncomeLoss",
                  "Assets", "RevenueFromContractWithCustomerExcludingAssessedTax",
                  "NetIncomeLoss",
                  "Assets", "NetIncomeLoss"],
        "ddate": [20231231] * 8,
        "qtrs":  [0, 4, 4, 0, 4, 4, 0, 4],
        "uom":   ["USD"] * 8,
        "value": [1_000_000, 500_000, 80_000,
                  2_500_000, 1_200_000, 150_000,
                  750_000, -30_000],
    })
    return sub, num


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------

def download_quarter(quarter: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Download the SEC DERA zip for *quarter* (e.g. '2023q4') and return
    (sub, num) DataFrames.

    Raises RuntimeError if the download fails.
    """
    try:
        import requests  # noqa: F401
    except ImportError:
        raise ImportError("Install requests: pip install requests")

    import requests

    url = SEC_URL_TEMPLATE.format(quarter=quarter)
    print(f"Downloading: {url}", flush=True)
    print("(This may take 30–120 seconds for large quarters)", flush=True)

    if not USER_AGENT or "@" not in USER_AGENT:
        raise SystemExit(
            "Set SEC_USER_AGENT to your name and email first, e.g.\n"
            '  export SEC_USER_AGENT="Jane Doe jane.doe@yale.edu"\n'
            "SEC requires this on every request."
        )
    headers = {"User-Agent": USER_AGENT}
    resp = requests.get(url, headers=headers, timeout=120)

    if resp.status_code != 200:
        raise RuntimeError(
            f"HTTP {resp.status_code} fetching {url}. "
            "Check the quarter string (e.g. '2023q4') and that the SEC "
            "DERA archive is available."
        )

    print(f"Downloaded {len(resp.content) / 1e6:.1f} MB", flush=True)

    with zipfile.ZipFile(io.BytesIO(resp.content)) as zf:
        names = zf.namelist()
        print(f"Zip contains: {names}", flush=True)

        # SEC naming convention: sub.txt and num.txt (may be in a subfolder).
        def read_txt(target: str) -> pd.DataFrame:
            matches = [n for n in names if n.lower().endswith(target)]
            if not matches:
                raise RuntimeError(f"'{target}' not found in zip. Files: {names}")
            with zf.open(matches[0]) as f:
                return pd.read_csv(f, sep="\t", low_memory=False,
                                   encoding="latin-1")

        sub = read_txt("sub.txt")
        num = read_txt("num.txt")

    print(f"sub.txt: {len(sub):,} rows | num.txt: {len(num):,} rows", flush=True)
    return sub, num


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build SEC-based fallback sample panel for the Module 4 lab."
    )
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument(
        "--quarter",
        metavar="YYYYqN",
        help="SEC DERA quarter to download, e.g. 2023q4",
    )
    mode.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate pipeline logic on a tiny synthetic frame; no download.",
    )
    parser.add_argument(
        "--out-dir",
        default=".",
        metavar="DIR",
        help="Output directory for fallback_panel.parquet and .csv (default: .)",
    )
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # -----------------------------------------------------------------------
    # Load data
    # -----------------------------------------------------------------------
    if args.dry_run:
        print("=== DRY-RUN MODE: using synthetic data ===", flush=True)
        sub, num = _synthetic_frame()
        print(f"Synthetic sub: {len(sub)} rows | num: {len(num)} rows",
              flush=True)
    else:
        sub, num = download_quarter(args.quarter)

    # -----------------------------------------------------------------------
    # Shape panel
    # -----------------------------------------------------------------------
    print("Shaping panel...", flush=True)
    panel = _shape_panel(sub, num)
    print(f"Output panel: {len(panel):,} rows, {panel.shape[1]} columns",
          flush=True)
    print(panel.dtypes.to_string(), flush=True)
    print("\nHead (5 rows):", flush=True)
    print(panel.head().to_string(index=False), flush=True)

    # -----------------------------------------------------------------------
    # Save
    # -----------------------------------------------------------------------
    if args.dry_run:
        print("\n=== DRY-RUN: skipping file write ===", flush=True)
        print("Pipeline validated successfully.", flush=True)
        sys.exit(0)

    parquet_path = out_dir / "fallback_panel.parquet"
    csv_path = out_dir / "fallback_panel.csv"

    # Cast float columns to Float64 (nullable) for clean parquet output.
    for col in ["at", "sale", "ni"]:
        if col in panel.columns:
            panel[col] = panel[col].astype("Float64")

    table = pa.Table.from_pandas(panel, preserve_index=False)
    pq.write_table(table, parquet_path, compression="snappy")
    panel.to_csv(csv_path, index=False)

    size_mb = parquet_path.stat().st_size / 1e6
    print(f"\nWrote: {parquet_path}  ({size_mb:.2f} MB)", flush=True)
    print(f"Wrote: {csv_path}", flush=True)
    print("Done.", flush=True)


if __name__ == "__main__":
    main()
