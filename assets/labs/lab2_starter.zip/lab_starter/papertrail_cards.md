# Paper-Trail Cards: DECISIONS.md and LOG.md

Two short reference cards. Read both before you send your opening prompt.
Paper-trail prompting means you ask for these files *before* any analysis
runs, not after you have built something and want to document it in
hindsight.

---

## Card 1: DECISIONS.md

**What it is.** A running record of every methodological choice made
during the pipeline, written when the choice is made rather than
reconstructed afterward from memory. Every choice the data does not force
on you gets one entry: which tag you chose when more than one was
available, the tie-break rule for duplicate rows, a filter you applied and
why.

**What a good entry looks like:**

> **2026-XX-XX — Tag selection for R&D expense.** Two candidate XBRL tags
> reported R&D-related values in the sample: `ResearchAndDevelopmentExpense`
> and `ResearchAndDevelopmentExpenseExcludingAcquiredInProcessCost`. Used
> the former, which had broader coverage across filers in this sample
> (94% vs. 61% of 10-K filings). Filers reporting only the latter tag are
> excluded from the R&D-intensity panel — see attrition row 3.

**What a weak entry looks like, and why it's weak:**

> **Fixed the R&D data.**

This entry does not say what the choice was, why it was made, or what it
affects downstream. If you could not reconstruct the decision from the
entry alone six months from now, the entry is not doing its job.

**The test.** If you deleted your entire chat session right now, would
DECISIONS.md still tell a stranger why the pipeline made each of its
choices? If not, the file lists topics but does not record decisions.

---

## Card 2: LOG.md

**What it is.** A timestamped line for every major step the pipeline
runs. It is not every line of code and not a copy of the terminal output.
Each line is a short statement of what happened and when, written for
someone reading it later rather than someone watching the run live.

**What a good log looks like:**

```
2026-XX-XX 14:02  Downloaded FSDS 2012Q4–2023Q4 (5 quarters, 5 zips).
2026-XX-XX 14:06  Extracted sub.txt, num.txt from each quarter.
2026-XX-XX 14:09  Joined sub/num on adsh. Rows: sub=48213, num=1822004,
                   joined=1801997 (22 unmatched adsh values dropped).
2026-XX-XX 14:14  Filtered to form=10-K, qtrs=0 (Assets), qtrs=4 (R&D tag).
                   n=14208 -> n=6112.
2026-XX-XX 14:15  Dropped 41 duplicate (adsh, tag, ddate, qtrs) rows,
                   keeping the finer-precision value. n=6112 -> n=6071.
2026-XX-XX 14:22  Aggregated median R&D/Assets by sic1 x year.
2026-XX-XX 14:31  Rendered rd_intensity.png. Sanity checks: see
                   DECISIONS.md entries 4 and 5.
```

**What LOG.md is not.** It does not replace DECISIONS.md. LOG.md records
*that* something happened and *when*. DECISIONS.md records *why* you chose
to do it that way. A pipeline needs both: the log shows you what the run
did, and the decisions file tells you whether to trust it.

---

## Why both are requested in the opening prompt, not added afterward

If you ask for these files only after you have seen the figure and it
looks right, you are reconstructing your reasoning after the fact. Module 1
warned you that this kind of memory disappears when a session ends.
Requesting both files in the opening prompt means each entry is written as
the choice is made. That is the only way the files end up as an honest
record rather than a tidy story written after you already know the answer.
