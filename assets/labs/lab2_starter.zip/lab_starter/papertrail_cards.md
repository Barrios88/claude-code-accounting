# Paper-Trail Cards: DECISIONS.md and LOG.md

Two short reference cards. Read both before you send your opening prompt —
the point of paper-trail prompting is that you ask for these files *before*
any analysis runs, not after you've already built something and want to
document it in hindsight.

---

## Card 1: DECISIONS.md

**What it is.** A running record of every methodological choice made
during the pipeline, written at the moment the choice is made — not
reconstructed afterward from memory. Every choice that isn't forced by the
data itself (a chosen tag when more than one was available, a tie-break
rule for duplicate rows, a filter applied and the reason for it) gets one
entry.

**What a good entry looks like:**

> **2026-XX-XX — Tag selection for R&D expense.** Two candidate XBRL tags
> reported R&D-related values in the sample: `ResearchAndDevelopmentExpense`
> and `ResearchAndDevelopmentExpenseExcludingAcquiredInProcessCost`. Used
> the former, which had broader coverage across filers in this sample
> (94% vs. 61% of 10-K filings). Filers reporting only the latter tag are
> excluded from the R&D-intensity panel — see attrition row 3.

**What a weak entry looks like, and why it's weak:**

> **Fixed the R&D data.**

This says nothing about what the choice was, why it was made, or what it
affects downstream. If you can't reconstruct the decision from the entry
alone six months from now, it isn't doing its job.

**The test.** If you deleted your entire chat session right now, would
DECISIONS.md still tell a stranger why the pipeline made the choices it
made? If not, the file is a title, not a record.

---

## Card 2: LOG.md

**What it is.** A timestamped line for every major step the pipeline runs —
not every line of code, and not a copy of the terminal output, but a short
statement of what happened and when. Think of it as the pipeline narrating
its own progress for someone reading it later, not for someone watching it
run live.

**What a good log looks like:**

```
2026-XX-XX 14:02  Downloaded FSDS 2012Q4–2023Q4 (5 quarters, 5 zips).
2026-XX-XX 14:06  Extracted sub.txt, num.txt from each quarter.
2026-XX-XX 14:09  Joined sub/num on adsh. Rows: sub=48213, num=1822004,
                   joined=1801997 (22 unmatched adsh values dropped).
2026-XX-XX 14:14  Filtered to form=10-K, qtrs=0 (Assets), qtrs=4 (R&D tag).
                   n=14208 -> n=6112.
2026-XX-XX 14:15  Dropped 41 duplicate (adsh, tag, ddate, qtrs) rows,
                   keeping the finer-precision value. n=6112 -> n=6071.
2026-XX-XX 14:22  Aggregated median R&D/Assets by sic1 x year.
2026-XX-XX 14:31  Rendered rd_intensity.png. Sanity checks: see
                   DECISIONS.md entries 4 and 5.
```

**What LOG.md is not.** It is not a substitute for DECISIONS.md — LOG.md
records *that* something happened and *when*; DECISIONS.md records *why*
you chose to do it that way. A pipeline needs both: the log tells you the
shape of the run, the decisions file tells you whether to trust it.

---

## Why both are requested in the opening prompt, not added afterward

If you ask for these files only after you've already seen the figure and
it looks right, you're reconstructing your reasoning after the fact — and
reconstructed memory is exactly the kind of state Module 1 warned you
disappears the moment a session ends. Building both files into the opening
prompt means they get written *as* each choice is made, which is the only
way they end up being an honest record rather than a tidy story invented
after you already know the answer.
