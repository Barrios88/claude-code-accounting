# Module 2 Verify Checklist

Self-graded and pass/fail, as in Module 1. Work through every line before
you consider the lab complete. When the course runs with a group, the
instructor spot-checks a sample rather than grading every box.

- [ ] Pipeline reruns start-to-finish from README instructions in a fresh
      clone of the folder

- [ ] `sub`/`num` joined on `adsh` (state row counts before/after join)

- [ ] Attrition table present; every sample-size change explained in
      DECISIONS.md

- [ ] `DATA_PROFILE.md` written before the first figure: what one row is, a
      uniqueness test with both counts, tag coverage by quarter, and your
      rule for prior-year duplicates and `10-K/A` amendments

- [ ] Raw firm-level series plotted before aggregation (and before and
      after winsorizing, if you winsorize)

- [ ] Two sanity checks written down, with sources: one benchmark
      comparison and one plausibility check

      Benchmark comparison: ____________________________________________

      Source: __________________________________________________________

      Plausibility check: ______________________________________________

      Source: __________________________________________________________

- [ ] Figure produced by a script; no interactive-only outputs anywhere

## If any box is unchecked

Do not erase the box. Note what is blocking it in your README. An honestly
unchecked box tells you, and anyone who reruns your work, more than a box
checked out of habit.

## Also: the WRDS checkpoint

This is separate from the checklist above. Before you start Module 4,
confirm that `ssh wrds` connects and a Duo push arrives (`tunnel_status.sh`,
Step 3 of the WRDS MCP Setup page). Module 4's main lab depends on this
connection, and fixing an account or Duo problem takes at least two days.
When the course runs with a group, this is a hard gate: you submit a
`tunnel_status` screenshot or a description of what went wrong on your exit
ticket.
