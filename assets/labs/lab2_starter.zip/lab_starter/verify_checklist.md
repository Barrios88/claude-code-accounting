# Day 2 Verify Checklist

Self-graded, pass/fail, same discipline as Day 1. Work through every line
before you consider the lab complete. The instructor will spot-check a
sample of these, not grade each box individually.

- [ ] Pipeline reruns start-to-finish from README instructions in a fresh
      clone of the folder

- [ ] `sub`/`num` joined on `adsh` (state row counts before/after join)

- [ ] Attrition table present; every sample-size change explained in
      DECISIONS.md

- [ ] Two sanity checks written down: one benchmark comparison, one
      plausibility check — with sources

      Benchmark comparison: ____________________________________________

      Source: __________________________________________________________

      Plausibility check: ______________________________________________

      Source: __________________________________________________________

- [ ] Figure produced by a script; no interactive-only outputs anywhere

## If any box is unchecked

Don't erase the box — note what's blocking it and bring it to the debrief
or flag it on your exit ticket. An honestly unchecked box is more useful to
the instructor than a box checked out of habit.

## Also today: the WRDS checkpoint

This is separate from the checklist above, but do not leave lab without it.
Submit either a `tunnel_status` screenshot (`ssh wrds` → Duo push →
success) or a Duo problem flag on your exit ticket. This is a hard gate —
Day 4's flagship lab depends on it. See the module page and lab page for
why the two-day runway matters.
