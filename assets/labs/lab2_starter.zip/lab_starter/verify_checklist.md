# Module 2 Verify Checklist

Self-graded and pass/fail, as in Module 1. Work through every line before
you consider the lab complete. The instructor will spot-check a sample, not
grade every box.

- [ ] Pipeline reruns start-to-finish from README instructions in a fresh
      clone of the folder

- [ ] `sub`/`num` joined on `adsh` (state row counts before/after join)

- [ ] Attrition table present; every sample-size change explained in
      DECISIONS.md

- [ ] `DATA_PROFILE.md` written before the first figure: what one row is, a
      uniqueness test with both counts, tag coverage by quarter, and your
      rule for prior-year duplicates and `10-K/A` amendments

- [ ] Raw firm-level series plotted before aggregation (and before and
      after winsorizing, if you winsorize)

- [ ] Two sanity checks written down, with sources: one benchmark
      comparison and one plausibility check

      Benchmark comparison: ____________________________________________

      Source: __________________________________________________________

      Plausibility check: ______________________________________________

      Source: __________________________________________________________

- [ ] Figure produced by a script; no interactive-only outputs anywhere

## If any box is unchecked

Do not erase the box. Note what is blocking it and bring it to the debrief,
or flag it on your exit ticket. An honestly unchecked box tells the
instructor more than a box checked out of habit.

## Also today: the WRDS checkpoint

This is separate from the checklist above, but do not leave the lab without
it. On your exit ticket, submit either a `tunnel_status` screenshot
(`ssh wrds` → Duo push → success) or a flag describing your Duo problem.
This is a hard gate, because Module 4's main lab depends on this
connection. The module page and lab page explain why you need two days of
runway.
