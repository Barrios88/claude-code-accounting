# Opening Prompt Template — Module 2

This is the six-part structure from the module page's demo prompt, adapted for your lab. Fill
in the blanks for your chosen measure (Base: leverage; Standard: R&D
intensity by SIC1; Stretch: revenue concentration). Then paste the whole
thing as your opening prompt, before you ask for any code and before any
analysis runs. The DATA and PAPER TRAIL sections are already filled in.
Leave the paper-trail section exactly as written, and do not trim it if you
are short on time. It is the part that produces `DECISIONS.md`, `LOG.md`,
and `DATA_PROFILE.md`.

---

**DATA:** Download the FSDS quarterly zip files for these five quarters —
2013Q1, 2016Q1, 2019Q1, 2022Q1, 2024Q1, which hold most 10-Ks for fiscal
years 2012, 2015, 2018, 2021, and 2023 — from the SEC's Financial Statement
Data Sets page. From each quarter we need two files: `sub.txt` (filing
metadata: `adsh`, `cik`, `sic`, `form`, `fy` (fiscal year), period) and
`num.txt` (tagged numeric values: `adsh`, `tag`, `version`, `ddate`, `qtrs`,
`uom`, `segments`, `coreg`, `value`). Read `num.txt` one quarter at a time
and keep only the tags and columns you need before combining quarters.

**JOIN:** Merge `sub.txt` and `num.txt` on `adsh` — the filing's accession
number, the only key that reliably links the two files. State the row count
in each file before the join and the row count after, and flag any `adsh`
values in `num.txt` with no match in `sub.txt`. Keep only consolidated,
parent-registrant values: rows where `segments` and `coreg` are blank and
`uom` is `USD`. Report the row count before and after this filter. Then
check for remaining duplicate `(adsh, tag, ddate, qtrs)` rows and document
a tie-break rule if you find any.

**MEASURE:** <TODO — name your measure>, defined as <TODO — numerator>
divided by <TODO — denominator> (or however it's computed) at the
<TODO — filer-period / filer-year> level. Use the XBRL tag(s)
`<TODO>` for the numerator and `<TODO>` for the denominator. State which
`qtrs` value you're keeping for each tag and why (zero for a balance-sheet
snapshot; four for a full fiscal year of a flow variable), and restrict to
`form = <TODO — usually 10-K>`.

- *Base (leverage):* numerator tag is commonly `LongTermDebtNoncurrent` or
  `LongTermDebt`; denominator tag is `Assets`. The debt tags cover only
  about a third of 10-K filers, so say whether a missing debt tag counts as
  zero or as missing.
- *Standard (R&D, different grain):* numerator tag is
  `ResearchAndDevelopmentExpense`; denominator tag is `Assets`; aggregate by
  one-digit SIC (`sic1`) instead of the demo's `sic2`.
- *Stretch (revenue concentration):* this measure doesn't have a
  numerator/denominator ratio at the filer-period level — instead, specify
  which revenue tag(s) you'll accept (e.g. `Revenues`, and
  `RevenueFromContractWithCustomerExcludingAssessedTax`, which more filers
  use than `Revenues` after the 2018 revenue standard), and how you'll rank filers by size
  within a year before taking the top ten.

**AGGREGATION:** Compute the <TODO — mean / median / sum / share> by
<TODO — grouping variable(s), e.g. `sic1` or none> and <TODO — time unit,
usually fiscal year (`fy` in `sub.txt`)>, across all five quarters.

**OUTPUT:** One <TODO — figure type, e.g. line figure, bar figure> formatted
for a working-paper draft — white background, labeled axes, a legend if
there's more than one series, no default plotting-library styling — saved
as `<TODO — filename.png>`. Save the underlying aggregated table as
`<TODO — filename.csv>`.

**PAPER TRAIL:** Write every stage as a named script — no output that exists
only as a chat reply. Keep a `DECISIONS.md` recording every methodological
choice as it's made — which tag was chosen when more than one was
available, how duplicate rows were handled, any filter applied and why.
Keep a `LOG.md` with a timestamped line for every major step. Print an
attrition row — n before, n after, reason — every time the sample size
changes.
Before computing any measure or drawing any figure, write a
`DATA_PROFILE.md`: what one row of each table is, a uniqueness test on that
row (report the row count and the count of distinct key combinations), the
share of 10-K filings in each quarter that report each tag you use, and the
rule for prior-year duplicates and `10-K/A` amendments.

---

## Before you send this

Check that every `<TODO>` is filled in. A leftover blank in the MEASURE or
AGGREGATION section is the kind of ambiguity Module 1 taught you to close
before you press Enter, not after.
