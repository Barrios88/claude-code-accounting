# Opening Prompt Template — Day 2

This is the six-part structure from today's demo, adapted for your lab. Fill
in the blanks for your chosen measure (Base: leverage; Standard: R&D
intensity by SIC1; Stretch: revenue concentration), then paste the whole
thing as your opening prompt — before you ask for any code, before any
analysis runs. The DATA and PAPER TRAIL sections are filled in for you
already; leave the paper-trail section exactly as written. It is built in on
purpose, not a section to trim if you're short on time.

---

**DATA:** Download the FSDS quarterly zip files for these five quarters —
2012Q4, 2015Q4, 2018Q4, 2021Q4, 2023Q4 — from the SEC's Financial Statement
Data Sets page. From each quarter we need two files: `sub.txt` (filing
metadata: `adsh`, `cik`, `sic`, `form`, fiscal year end, period) and
`num.txt` (tagged numeric values: `adsh`, `tag`, `ddate`, `qtrs`, `value`).

**JOIN:** Merge `sub.txt` and `num.txt` on `adsh` — the filing's accession
number, the only key that reliably links the two files. State the row count
in each file before the join and the row count after, and flag any `adsh`
values in `num.txt` with no match in `sub.txt`. Check for and handle
duplicate `(adsh, tag, ddate, qtrs)` rows before aggregating — decide and
document a tie-break rule if you find any.

**MEASURE:** <TODO — name your measure>, defined as <TODO — numerator>
divided by <TODO — denominator> (or however it's computed) at the
<TODO — filer-period / filer-year> level. Use the XBRL tag(s)
`<TODO>` for the numerator and `<TODO>` for the denominator. State which
`qtrs` value you're keeping for each tag and why (zero for a balance-sheet
snapshot; four for a full fiscal year of a flow variable), and restrict to
`form = <TODO — usually 10-K>`.

- *Base (leverage):* numerator tag is commonly `LongTermDebtNoncurrent` or
  `LongTermDebt`; denominator tag is `Assets`.
- *Standard (R&D, different grain):* numerator tag is
  `ResearchAndDevelopmentExpense`; denominator tag is `Assets`; aggregate by
  one-digit SIC (`sic1`) instead of the demo's `sic2`.
- *Stretch (revenue concentration):* this measure doesn't have a
  numerator/denominator ratio at the filer-period level — instead, specify
  which revenue tag(s) you'll accept (e.g. `Revenues`, and a fallback tag
  for filers that don't report it), and how you'll rank filers by size
  within a year before taking the top ten.

**AGGREGATION:** Compute the <TODO — mean / median / sum / share> by
<TODO — grouping variable(s), e.g. `sic1` or none> and <TODO — time unit,
usually calendar year>, across all five quarters.

**OUTPUT:** One <TODO — figure type, e.g. line figure, bar figure> formatted
for a working-paper draft — white background, labeled axes, a legend if
there's more than one series, no default plotting-library styling — saved
as `<TODO — filename.png>`. Save the underlying aggregated table as
`<TODO — filename.csv>`.

**PAPER TRAIL:** Write every stage as a named script — no output that exists
only as a chat reply. Keep a `DECISIONS.md` recording every methodological
choice as it's made — which tag was chosen when more than one was
available, how duplicate rows were handled, any filter applied and why.
Keep a `LOG.md` with a timestamped line for every major step. Print an
attrition row — n before, n after, reason — every time the sample size
changes.

---

## Before you send this

Check every `<TODO>` is filled in — a leftover blank in the MEASURE or
AGGREGATION section is exactly the kind of ambiguity Day 1 taught you to
close before you hit enter, not after.
