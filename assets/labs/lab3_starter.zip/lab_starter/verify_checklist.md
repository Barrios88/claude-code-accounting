# Module 3 Verify Checklist

Self-graded, pass/fail. Work through every line before you consider the lab
complete. The instructor will spot-check a sample, not grade every box. What
counts is your own honest sign-off, the same habit you used in Modules 1
and 2.

- [ ] Cache works: re-running the pipeline downloads zero already-fetched
      filings.

- [ ] Quality report: extraction rate stated and at least 95 percent before
      you move to Part B; every failure has a one-line diagnosis.

- [ ] Result table reproduced by named scripts from README.

- [ ] Validity paragraph + audit-sample protocol written (do not claim the
      *measure* is valid; the protocol is the deliverable).

- [ ] SKILL.md: description is a trigger condition (not a title) and the
      skill fires in a fresh session.

- [ ] Rate limit respected (≤10 req/sec) and User-Agent set — show the
      code line.

## If any box is unchecked

Do not erase the box. Note what is blocking it and bring it to the debrief,
or flag it on your exit ticket. An honestly unchecked box tells the
instructor more than a box checked out of habit.
