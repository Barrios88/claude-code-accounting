# Module 3 Verify Checklist

Self-graded, pass/fail. Work through every line before you consider the lab
complete. The instructor will spot-check a sample of these, not grade each
box individually — the point is your own honest sign-off, the same
discipline you used on Module 1 and Module 2.

- [ ] Cache works: re-running the pipeline downloads zero already-fetched
      filings.

- [ ] Quality report: extraction rate stated; every failure has a one-line
      diagnosis.

- [ ] Result table reproduced by named scripts from README.

- [ ] Validity paragraph + audit-sample protocol written (the *measure* is
      not claimed valid — the protocol is the deliverable).

- [ ] SKILL.md: description is a trigger condition (not a title) and the
      skill fires in a fresh session.

- [ ] Rate limit respected (≤10 req/sec) and User-Agent set — show the
      code line.

## If any box is unchecked

Don't erase the box — note what's blocking it and bring it to the debrief
or flag it on your exit ticket. An honestly unchecked box is more useful to
the instructor than a box checked out of habit.
