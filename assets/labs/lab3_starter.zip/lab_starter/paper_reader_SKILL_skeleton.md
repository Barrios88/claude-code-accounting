<!--
SKILL.md skeleton for a paper-reading skill (Module 3 lab, Part C stretch)

This is a template, not a finished skill. Because you will use it on every
paper you read, not just this project's, install it at global scope:
`~/.claude/skills/paper-reader/SKILL.md`. Fill in every TODO, delete the
comment blocks, and test it in a fresh session before you rely on it.
-->

---
name: paper-reader
description: <TODO: write this as a trigger condition, not a title. For
  example: Use when the user asks to read, summarize, or take notes on an
  academic paper (a PDF, or an SSRN or arXiv link), or asks what a paper's
  identification strategy or main result is.>
---

## What this skill does

Reads one empirical paper and writes structured notes to a file, in the
same format every time, with a table and column cited for every number.

## Inputs

- The paper: a PDF path or a URL.
- <TODO: where the notes should go, e.g. `notes/papers/`>

## Steps

1. If the PDF is long (roughly 30 pages or more, or it has an online
   appendix), split it into sections and read them in order. Do not read
   the whole file into the conversation at once.
2. Write the notes to `<notes folder>/<first-author>_<year>.md` as you go,
   using the template below.
3. For every number in the notes (each N and each coefficient), record the
   table and column it comes from. If you cannot find a number in a table,
   write "not found" rather than estimating it.
4. Report the path to the notes file and list every number you could not
   find.

## Notes template

- **Citation:** authors, year, title, journal or working-paper series.
- **Question:** what the paper asks, in one sentence.
- **Setting:** the institutional detail the design depends on (the
  regulation, market, or reporting rule).
- **Sample:** data sources, years, filters, and the N after each filter,
  each with its table reference.
- **Identifying variation:** what changes for some firms and not others,
  and why the authors argue it is unrelated to the outcome.
- **Main result:** headline coefficient and standard error (table,
  column), and what the magnitude means in economic terms.
- **Replication:** whether the data are available to you, and which parts
  of the analysis you could rebuild.
- <TODO: add any field you always want, e.g. "Related to my project
  because...">

## Test checklist (delete before shipping, keep while building)

- [ ] Tested in a fresh session, not the one used to build it
- [ ] Fired on a natural request ("take notes on this paper") without
      naming the skill file
- [ ] Every N and coefficient in the notes checked against the PDF's
      tables; number of errors written down
