<!--
SKILL.md skeleton — Day 3 lab, Part C

This is a template, not a finished skill. Save it as
`.claude/skills/edgar-panel/SKILL.md` in your project (project scope, not
global — this pipeline is tied to this project's data and CIK list), fill
in every TODO, delete the comment blocks, and test-fire it in a fresh
session before you consider it done.

Anatomy of this file, top to bottom:
  1. YAML frontmatter: name + description.
  2. The description-as-TRIGGER warning (read this before you write yours).
  3. Numbered procedure steps.
  4. Pointers to supporting resources (files this skill's steps reference).
-->

---
name: edgar-panel
description: <TODO — see the warning below before you write this>
---

<!--
================================================================
WARNING: description is a TRIGGER CONDITION, not a title.
================================================================

The single most common mistake in a first skill is writing the description
as a label for what the skill is, e.g.:

    description: EDGAR filing tool

This looks correct. It is valid YAML. It will never fire. "EDGAR filing
tool" describes the skill; it gives nothing for the matching logic to
recognize in an actual request. A student types "get me risk factor counts
for these tickers" and nothing in "EDGAR filing tool" connects to that
sentence — the skill sits in the folder, unused, and the failure is
invisible until you go looking for it in a fresh session.

Write the description as the situations a real request will actually look
like. A working version:

    description: Use when the user asks to scrape 10-K filings, build an
      EDGAR text dataset, or names a set of tickers or CIKs alongside a
      form type (10-K, 10-Q) and a date range.

Before you finalize your TODO above, ask yourself: if I typed a natural
request into a fresh session without naming this skill file, would this
description's wording actually match what I said? If you're not sure,
that's the sign to rewrite it, not to move on.
================================================================
-->

## What this skill does

<TODO: one or two sentences — the plain-language version of "build an
EDGAR text panel from a CIK list, with caching, quality reporting, and a
keyword measure loaded into DuckDB.">

## Inputs

<TODO — name these precisely; this is where a first attempt most often
goes vague. Example:
- A CIK list (path to a CSV with a `cik` column, zero-padded 10 digits)
- A form type (e.g. "10-K")
- A fiscal-year range (e.g. 2021-2023)
- A keyword list for the measure being computed>

## Steps

<TODO — write these as the actual procedure, in order, the way you'd
explain it to a new RA on their first day. A skeleton to adapt:

1. Resolve each CIK's filing index via the EDGAR submissions endpoint.
   Respect the 10 req/sec rate limit and set the User-Agent header on
   every request (see `resources/frontloaded_prompt_template.md` for the
   exact wording).
2. Download raw filing HTML to `data/filings/`, one file per filing.
   Before downloading, check whether the file already exists — never
   re-fetch a filing already cached.
3. Extract the Item 1A section using the fallback regex chain (see
   `resources/regex_patterns.md` if you've saved one). Flag any
   suspiciously short match for manual review rather than accepting it
   silently.
4. Load filings, sections, and a keywords table into DuckDB at the path
   specified in the inputs.
5. Produce a quality report: total attempted, successes, failures, and a
   one-line diagnosis for every failure.
6. Report the extraction rate and the path to the output DuckDB file.
>

## Output structure

<TODO — state exactly what this skill leaves behind when it finishes, not
just what it does along the way. Example:
- `<name>.duckdb` with tables `filings`, `sections`, `keywords`
- `metadata.csv` describing each table's columns
- `quality_report.txt` with the extraction rate and per-failure diagnoses>

## Resources

<TODO — list any supporting files this skill's steps point to, e.g. a
saved regex-pattern reference or the front-loaded prompt template it was
built from. Delete this section if the skill is fully self-contained.>

## Test-fire checklist (delete before shipping, keep while building)

- [ ] Tested in a genuinely fresh session, not the one used to build it
- [ ] Fired on a natural request without naming the skill file directly
- [ ] Run on at least one CIK not used while developing the skill
- [ ] Produced the exact output structure specified above
