# Front-Loaded EDGAR Prompt Template

<!--
This template exists because of one lesson from today's lecture: the biggest
time-saver on an EDGAR pipeline is not better code, it's a better first
prompt. Every operational fact below is something you already know before
you start — the CIK concept, the rate limit, the User-Agent requirement.
Putting them in the prompt up front means Claude doesn't have to discover
them the hard way (a 403, a rate-limit block) before it can start actually
building your pipeline.

Fill in the four TODOs, delete this comment block, and paste the result as
your opening prompt for Part A of today's lab.
-->

## The prompt

Fetch the Item 1A Risk Factors section from the 10-Ks filed by the CIKs in
`pinned_ciks.csv`, for fiscal years <TODO: e.g. 2021-2023>. Use the SEC
EDGAR full-text search endpoint (`efts.sec.gov`) to locate filings and the
per-filer submissions endpoint (`data.sec.gov/submissions/CIK##########.json`)
to confirm accession numbers.

**Operational constraints — respect these on every request:**

- Rate limit: no more than 10 requests per second.
- User-Agent header: set to `<TODO: your-name@your-institution.edu>` on
  every single request. Do not send a blank or default User-Agent — EDGAR
  will reject the request.
- Cache raw filing HTML to `data/filings/` (one file per filing, named
  predictably) before running any extraction logic, so a re-run after a
  regex fix never re-downloads a file that already succeeded.

**Extraction:**

- Use a fallback chain of regex patterns to locate the Item 1A heading —
  do not rely on a single pattern. Filers write the heading at least four
  different ways (all-caps, with a trailing period, split across a
  table-of-contents anchor, on its own line). If the cleanest pattern
  produces a suspiciously short match, fall through to a looser pattern
  and log which pattern actually fired.
- After extraction, produce a quality report: total filings attempted,
  successes, failures, and a one-line diagnosis for every failure.

**Measurement:**

- Compute a keyword count for the topic: <TODO: pick one — tariffs, cyber,
  climate, supply chain>. State the exact keyword list you're counting
  before you run it, not after.

**Output:**

- Load everything into a DuckDB file at `<TODO: e.g. edgar_panel.duckdb>`
  with three tables: `filings` (one row per CIK-fiscal year, cached file
  path, extraction status), `sections` (extracted text, keyed to the
  filing), and `keywords` (the counts computed above, keyed the same way).
- Produce one result table: the keyword measure by firm-fiscal-year,
  saved as a named script's output, not typed directly into the chat.

## Why this template looks the way it does

Every section above maps to a specific point from the lecture: the CIK/
rate-limit/User-Agent block is C-D3-01 and C-D1-13 (front-loaded context);
the fallback-chain instruction is C-D3-02; the caching instruction is
C-D3-03; the quality-report instruction is C-D3-05. None of this is
boilerplate for its own sake — each line exists because skipping it is a
specific, named way today's pipeline goes wrong.
