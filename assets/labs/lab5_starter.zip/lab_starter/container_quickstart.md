# Container Quick-Start — Environment Stretch

This covers the two sandboxing options for the capstone's environment
stretch: `claude-container` (Docker-based) and `agent-safehouse` (a
lighter, kernel-enforced, Mac-native alternative). Pick one — you don't
need both. Neither is required for the core rubric; this is the stretch
section.

**The one rule that matters more than which tool you pick:** YOLO mode
(`--dangerously-skip-permissions`) is safe *only* inside a properly bounded
sandbox. It is never appropriate on your host machine, regardless of how
well-behaved the agent has been so far. Everything below exists to make
YOLO-in-a-container categorically different from YOLO-on-host — not a
smaller version of the same risk, a different category of risk entirely.

---

## Option A: `claude-container` (Docker)

Requires Docker installed and running. Build once per machine, then run
per project.

```bash
# One-time image build (Dockerfile can be Claude-generated from a plain-
# English description of the tools you need: Python, R, LaTeX, DuckDB, etc.)
docker build -t econ-sandbox .

# Run Claude Code inside the sandbox, mounting only your project folder
# and your Claude auth directory — nothing else on the host is visible.
docker run --rm -it \
  -v "$PWD/replication":/home/rstudio/work \
  -v "$HOME/.claude":/home/rstudio/.claude \
  --cap-drop=ALL \
  --security-opt=no-new-privileges \
  econ-sandbox \
  claude --dangerously-skip-permissions
```

Notes:
- `--cap-drop=ALL` and `--security-opt=no-new-privileges` are not optional
  extras — they are what keeps the container from being able to escalate
  its own privileges. Never add `--privileged` to this command.
- First run requires one-time auth: Claude shows a link (no browser inside
  the container), you copy it out, authenticate, and paste the code back
  in. Auth persists in the mounted `~/.claude` directory afterward.
- Artifacts (scripts, output files, figures) accumulate only in the
  mounted `replication` folder and persist on the host after the container
  exits — nothing else the agent touches survives.

---

## Option B: `agent-safehouse` (lighter, Mac-native)

Kernel-enforced isolation without Docker overhead. Good default if you're
on a Mac and don't already have a Docker workflow running.

```bash
brew install eugene1g/safehouse/agent-safehouse
cd ~/your-project
safehouse claude --dangerously-skip-permissions
```

To selectively widen access (read-only) beyond the current project folder:

```bash
safehouse --add-dirs-ro=~/some-reference-folder -- claude --dangerously-skip-permissions
```

---

## The blocked-access proof (required for the stretch credit)

From inside either sandbox, run a command that should fail because it
reaches outside the mounted boundary. With `agent-safehouse`:

```bash
safehouse cat ~/.ssh/id_ed25519
```

**Expected output:** `Operation not permitted` — not a polite refusal from
the agent, a hard kernel-level denial. This is the proof to paste into your
capstone notes for the environment-stretch rubric line. A second good proof
is listing a folder outside the project:

```bash
safehouse ls ~/some-other-project
```

which should likewise fail, while `safehouse ls .` succeeds and shows only
the current project's contents.

With Docker (`claude-container`), the equivalent proof is simpler to reason
about but less dramatic to show: confirm that no host directory besides
the one you explicitly mounted with `-v` is visible from inside the
container at all (`ls /home/rstudio/` should show only what you mounted).

---

## What NOT to do

- Do not mount your home directory (`$HOME` or `~`) into either sandbox.
  That defeats the entire point — SSH keys, other projects, and every
  credential on the machine become reachable again.
- Do not run YOLO mode outside a sandbox "just this once" because the
  container setup felt like overhead. The whole reason this section exists
  is that the environment, not your judgment about the task, is what
  determines the risk.
- Do not treat a successful container run as proof that your data is
  private. A container limits what the agent can *do*; it does not limit
  what the agent can *see* once you've mounted a folder, and anything it
  reads can still be sent to a remote model as part of a normal session.
  If your project touches WRDS-licensed or otherwise sensitive data, that's
  a separate data-governance decision (see the module page's callout on
  this) — sandboxing does not resolve it by itself.
