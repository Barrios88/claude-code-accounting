# Container Quick-Start — Environment Stretch

This file covers the two sandboxing options for the capstone's
environment stretch: `claude-container` (Docker-based) and
`agent-safehouse` (a lighter, kernel-enforced, Mac-native alternative).
Pick one; you don't need both. Neither is required for the core rubric.
This is the stretch section.

**The rule that matters more than which tool you pick:** YOLO mode
(`--dangerously-skip-permissions`) is safe *only* inside a properly bounded
sandbox. Never use it on your host machine, however well the agent has
behaved so far. Inside a sandbox, the agent can reach only the folders you
mounted. On your host, it can reach everything your user account can.
Everything below exists to keep that boundary in place.

---

## Option A: `claude-container` (Docker)

Requires Docker installed and running. Build once per machine, then run
per project.

```bash
# One-time image build (Dockerfile can be Claude-generated from a plain-
# English description of the tools you need: Python, R, LaTeX, DuckDB, etc.)
docker build -t econ-sandbox .

# Run Claude Code inside the sandbox, mounting only your project folder
# and your Claude auth directory — nothing else on the host is visible.
docker run --rm -it \
  -v "$PWD/replication":/home/rstudio/work \
  -v "$HOME/.claude":/home/rstudio/.claude \
  --cap-drop=ALL \
  --security-opt=no-new-privileges \
  econ-sandbox \
  claude --dangerously-skip-permissions
```

Notes:
- `--cap-drop=ALL` and `--security-opt=no-new-privileges` are required,
  not optional extras. They keep the container from escalating its own
  privileges. Never add `--privileged` to this command.
- The first run needs a one-time login. There is no browser inside the
  container, so Claude shows a link; you copy it out, authenticate, and
  paste the code back in. The login persists in the mounted `~/.claude`
  directory after that.
- Artifacts (scripts, output files, figures) accumulate only in the
  mounted `replication` folder and stay on the host after the container
  exits. Nothing else the agent touches survives.

---

## Option B: `agent-safehouse` (lighter, Mac-native)

Kernel-enforced isolation without Docker overhead. A good default if
you're on a Mac and don't already use Docker.

```bash
brew install eugene1g/safehouse/agent-safehouse
cd ~/your-project
safehouse claude --dangerously-skip-permissions
```

To selectively widen access (read-only) beyond the current project folder:

```bash
safehouse --add-dirs-ro=~/some-reference-folder -- claude --dangerously-skip-permissions
```

---

## The blocked-access proof (required for the stretch credit)

From inside either sandbox, run a command that should fail because it
reaches outside the mounted boundary. With `agent-safehouse`:

```bash
safehouse cat ~/.ssh/id_ed25519
```

**Expected output:** `Operation not permitted`. This is a kernel-level
denial, not a refusal from the agent. Paste it into your capstone notes for
the environment-stretch rubric line. A second good proof is listing a
folder outside the project:

```bash
safehouse ls ~/some-other-project
```

which should likewise fail, while `safehouse ls .` succeeds and shows only
the current project's contents.

With Docker (`claude-container`), the equivalent proof is easier to reason
about but less visible: confirm that no host directory other than the ones
you mounted with `-v` is visible from inside the container
(`ls /home/rstudio/` should show only what you mounted).

---

## What NOT to do

- Do not mount your home directory (`$HOME` or `~`) into either sandbox.
  That makes SSH keys, other projects, and every credential on the machine
  reachable again, which removes the protection the sandbox gives you.
- Do not run YOLO mode outside a sandbox "just this once" because the
  container setup felt like overhead. The risk depends on the environment
  the agent runs in, not on your judgment about the task. That is why this
  section exists.
- Do not treat a successful container run as proof that your data is
  private. A container limits what the agent can *do*. It does not limit
  what the agent can *see* in a folder you mounted, and anything it reads
  can still be sent to a remote model as part of a normal session. If your
  project touches WRDS-licensed or otherwise sensitive data, that is a
  separate data-governance decision (see the module page's callout on
  this). Sandboxing does not settle it.
