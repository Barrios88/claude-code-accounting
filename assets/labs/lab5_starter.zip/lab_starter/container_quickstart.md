# Container Quick-Start — Environment Stretch

This file covers three sandboxing options for the capstone's environment
stretch: a Docker dev container, `agent-safehouse` (a lighter,
kernel-enforced, Mac-native alternative) and Claude Code's built-in
`/sandbox` (macOS and Linux). Pick one; you don't need more. None is
required for the core rubric. This is the stretch section.

**The rule that matters more than which tool you pick:** YOLO mode
(`--dangerously-skip-permissions`) is safe *only* inside a properly bounded
sandbox. Never use it on your host machine, however well the agent has
behaved so far. Inside a sandbox, the agent can reach only the folders you
mounted. On your host, it can reach everything your user account can.
Everything below exists to keep that boundary in place.

---

## Option A: a Docker dev container

Requires Docker. Don't write a container from scratch. Start from
Anthropic's reference dev container, which runs Claude Code as a non-root
user (the CLI refuses `--dangerously-skip-permissions` when run as root)
and limits outbound network traffic with a firewall:

- Guide: https://code.claude.com/docs/en/devcontainer
- Files to copy into your project: the `.devcontainer/` folder of
  https://github.com/anthropics/claude-code

Copy that `.devcontainer/` folder into your capstone project, open the
project in VS Code (or any editor that supports dev containers), and run
**Dev Containers: Reopen in Container**. Then, in the container's terminal:

```bash
claude --dangerously-skip-permissions
```

Notes:
- Only your project folder is mounted. Your Claude login is kept in a
  Docker volume of its own, not in your host's `~/.claude`, so the agent
  can't read your other projects' session history.
- Don't add mounts for `~/.ssh`, `~/.wrds-mcp.env` or your home directory.
- Anthropic's own warning applies: in this mode the container does not
  stop a malicious project from sending out anything inside the container,
  including your Claude login. Use it with your own code only.
- Scripts, output files and figures written to the project folder stay on
  the host after the container exits.

---

## Option B: `agent-safehouse` (lighter, Mac-native)

Kernel-enforced isolation without Docker overhead. A good default if
you're on a Mac and don't already use Docker.

```bash
brew install eugene1g/safehouse/agent-safehouse
cd ~/your-project
safehouse claude --dangerously-skip-permissions
```

To selectively widen access (read-only) beyond the current project folder:

```bash
safehouse --add-dirs-ro=~/some-reference-folder -- claude --dangerously-skip-permissions
```

---

## Option C: Claude Code's built-in sandbox (macOS and Linux)

Run `/sandbox` inside a Claude Code session and turn it on. On macOS it
uses the same kernel mechanism as safehouse; on Linux and WSL2 install
`bubblewrap` and `socat` first (for example
`sudo apt-get install bubblewrap socat`). It covers shell commands and
the programs they start, not Claude's built-in file tools, which follow
your permission rules. By default it still lets commands **read** most of
your machine, including `~/.ssh`. Hide your home folder, except the
project, in the project's `.claude/settings.json` before you run the proof
below:

```json
{
  "sandbox": {
    "enabled": true,
    "filesystem": { "denyRead": ["~/"], "allowRead": ["."] }
  }
}
```

Details: https://code.claude.com/docs/en/sandboxing

Because Claude's file tools run outside this sandbox, keep normal
permission prompts or auto mode on with Option C. It is not a place for
`--dangerously-skip-permissions`.

---

## The blocked-access proof (required for the stretch credit)

From inside your sandbox, run a command that should fail because it
reaches outside the boundary. With `agent-safehouse`, from your project
folder:

```bash
safehouse cat ~/.ssh/id_ed25519
```

**Expected output:** `Operation not permitted`. This is a kernel-level
denial, not a refusal from the agent. Paste it into your capstone notes for
the environment-stretch rubric line. A second good proof is listing a
folder outside the project:

```bash
safehouse ls ~/some-other-project
```

which should likewise fail, while `safehouse ls .` succeeds and shows only
the current project's contents.

In the dev container, your host's home folder simply isn't there. From the
container's terminal, `cat /Users/<your-mac-username>/.ssh/id_ed25519` (or
`/home/<your-username>/.ssh/id_ed25519` on Linux) fails with
`No such file or directory`. That output counts for the rubric line.

With the built-in sandbox, ask Claude to run `cat ~/.ssh/id_ed25519` with
the settings above in place. The command should fail with an error from the
operating system, not a refusal from Claude. Paste the output.

---

## What NOT to do

- Do not mount your home directory (`$HOME` or `~`) into either sandbox.
  That makes SSH keys, other projects, and every credential on the machine
  reachable again, which removes the protection the sandbox gives you.
- Do not run YOLO mode outside a sandbox "just this once" because the
  container setup felt like overhead. The risk depends on the environment
  the agent runs in, not on your judgment about the task. That is why this
  section exists.
- Do not treat a successful container run as proof that your data is
  private. A container limits what the agent can *do*. It does not limit
  what the agent can *see* in a folder you mounted, and anything it reads
  can still be sent to a remote model as part of a normal session. If your
  project touches WRDS-licensed or otherwise sensitive data, that is a
  separate data-governance decision (see the module page's callout on
  this). Sandboxing does not settle it.
