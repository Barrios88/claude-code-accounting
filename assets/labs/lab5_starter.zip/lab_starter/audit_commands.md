# Credential Hygiene Audit — Two Commands

Run both from the root of your capstone project. Both should come back
clean. Paste both outputs into your capstone notes — "it's clean" is not
the deliverable; the pasted output is.

## Command 1: has a `.env` ever been committed?

```bash
git log --all --full-history -- .env
```

**Expected output:** nothing — an empty result.

If this returns even one commit, a `.env` file was committed at some point
in this repository's history. Deleting the file now does **not** remove it
from history: anyone who clones the repo, including a coauthor, a referee
running a replication package, or a stranger on GitHub, can still find it
in an old commit with `git show <commit>:.env`.

## Command 2: does a credential string appear anywhere in the working tree?

```bash
grep -r "WRDS_PASSWORD" .
```

**Expected output:** nothing.

Run the equivalent search for every credential name your project actually
uses — API keys, other passwords, tokens — not just this one example.
Check scripts, notebooks, README files, and any stray text or log files;
credentials leak into all of these, not just `.env`.

## If either command finds something

1. **Treat the credential as compromised, immediately** — not "probably
   fine because no one saw it." A credential that has ever been committed
   to a git repository must be assumed exposed, even in a private repo,
   even if you never pushed it anywhere.
2. **Revoke and rotate first, clean up second.** Request a new WRDS
   password (or regenerate the API key) before you touch the repository.
   The order matters: cleaning the repo first and rotating later leaves
   the exposed credential live and unrotated while you work.
3. **Remove it from history, not just the current version.** Deleting the
   current copy of a secret while leaving it reachable in `git log`
   history fixes nothing — a `git filter-repo` or BFG-style history rewrite
   (or, more simply, starting a fresh repository if the project is small
   and early) is what actually removes it.
4. **Confirm the fix** by re-running both commands above and getting a
   clean result before you consider the audit passed.

## Also confirm, while you're here

- `.gitignore` excludes `.env`, any raw WRDS-derived data files, and any
  other credential or licensed-data file your project touches.
- If your pipeline used a WRDS Duo/SSH tunnel, confirm it is closed
  (`exit` the tunnel session) — a running tunnel with an active agent
  session is the specific failure mode this audit is meant to catch before
  it becomes a real exposure.
