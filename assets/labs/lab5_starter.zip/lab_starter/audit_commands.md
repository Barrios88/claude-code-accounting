# Credential Hygiene Audit — Two Checks

Run both from the root of your capstone project. Both should come back
clean. Paste both outputs into your capstone notes. Writing "it's clean" is
not the deliverable; the pasted output is.

## Check 1: has a credential file ever been committed?

```bash
git log --all --full-history --oneline -- '*.env' '*.env.*' '.mcp.json'
```

**Expected output:** nothing (an empty result).

This looks for a `.env` file, or a variant such as `.env.local`, in any
folder and at any point in the history, plus a project-level `.mcp.json`
(which holds credentials if you ever registered an MCP server with project
scope). If it returns even one commit, a credential file was committed at
some point. Deleting the file now does **not** remove it from history:
anyone who clones the repo, including a coauthor, a referee running a
replication package, or a stranger on GitHub, can still find it in an old
commit with `git show <commit>:<path>`.

## Check 2: does your actual password appear anywhere?

```bash
source ~/.wrds-mcp.env
: "${WRDS_PASSWORD:?source your env file first}"
git log --all --oneline -S"$WRDS_PASSWORD"
git grep -l -F --untracked -e "$WRDS_PASSWORD"
```

**Expected output:** nothing.

- Line 1 loads your password from the private file Module 4 set up,
  outside the project.
- Line 2 stops with an error if the password didn't load, so an empty
  search can't pass by accident.
- Line 3 lists every commit that ever added or removed the password,
  including in a script you have since deleted.
- Line 4 lists files git would pick up that contain it now. It skips
  gitignored files.

Both searches print commit IDs or file names, never the password. They look
for the password itself, not the name `WRDS_PASSWORD`, so a script that
reads the password from the environment (the right way) passes, and a
script with the password typed into it fails. Do not use a plain
`grep -r "WRDS_PASSWORD" .` instead: it flags correct code and misses a
password that was committed and later deleted.

Repeat Check 2 for every other secret the project uses (API keys, tokens):
type `read -s SECRET`, paste the key (it won't echo), and run the last two
lines with `$SECRET` in place of `$WRDS_PASSWORD`. On the public-data track
there is no WRDS password; run Check 1, and Check 2 only for any API keys
you used.

## If either check finds something

1. **Treat the credential as compromised right away.** Do not assume it is
   fine because no one saw it. Assume any credential that has ever been
   committed to a git repository is exposed, even in a private repo and
   even if you never pushed it anywhere.
2. **Revoke and rotate first, clean up second.** Request a new WRDS
   password (or regenerate the API key) before you touch the repository.
   The order matters. If you clean the repo first and rotate later, the
   exposed credential stays valid while you work.
3. **Remove it from history, not just the current version.** Deleting the
   current copy is not enough while the secret is still reachable in
   `git log` history. A history rewrite with `git filter-repo` or BFG
   removes it. If the project is small and early, starting a fresh
   repository is simpler.
4. **Confirm the fix** by re-running both checks above and getting a
   clean result before you consider the audit passed.

## Also confirm, while you're here

- `.gitignore` excludes `.env`, any raw WRDS-derived data files, and any
  other credential or licensed-data file your project touches, and none of
  them was ever committed. Adjust the paths to your project and paste the
  output, which should be empty:

  ```bash
  git log --all --full-history --oneline -- 'data/raw/*' '*.parquet' '*.dta' '*.csv'
  ```
- If your pipeline used a WRDS Duo/SSH tunnel, confirm it is closed
  (run `bash tunnel_down.sh`, then `bash tunnel_status.sh` to check, from
  the folder where you keep the tunnel scripts; see the WRDS MCP Setup page). A tunnel left running alongside an active
  agent session is one of the problems this audit is meant to catch before
  it leads to a real exposure.
