# Credential Hygiene Audit — Two Commands

Run both from the root of your capstone project. Both should come back
clean. Paste both outputs into your capstone notes. Writing "it's clean" is
not the deliverable; the pasted output is.

## Command 1: has a `.env` ever been committed?

```bash
git log --all --full-history -- .env
```

**Expected output:** nothing (an empty result).

If this returns even one commit, a `.env` file was committed at some point
in this repository's history. Deleting the file now does **not** remove it
from history: anyone who clones the repo, including a coauthor, a referee
running a replication package, or a stranger on GitHub, can still find it
in an old commit with `git show <commit>:.env`.

## Command 2: does a credential string appear anywhere in the working tree?

```bash
grep -r "WRDS_PASSWORD" .
```

**Expected output:** nothing.

Run the equivalent search for every credential name your project actually
uses — API keys, other passwords, tokens — not just this one example.
Check scripts, notebooks, README files, and any stray text or log files.
Credentials can end up in any of these, not only in `.env`.

## If either command finds something

1. **Treat the credential as compromised right away.** Do not assume it is
   fine because no one saw it. Assume any credential that has ever been
   committed to a git repository is exposed, even in a private repo and
   even if you never pushed it anywhere.
2. **Revoke and rotate first, clean up second.** Request a new WRDS
   password (or regenerate the API key) before you touch the repository.
   The order matters. If you clean the repo first and rotate later, the
   exposed credential stays valid while you work.
3. **Remove it from history, not just the current version.** Deleting the
   current copy is not enough while the secret is still reachable in
   `git log` history. A history rewrite with `git filter-repo` or BFG
   removes it. If the project is small and early, starting a fresh
   repository is simpler.
4. **Confirm the fix** by re-running both commands above and getting a
   clean result before you consider the audit passed.

## Also confirm, while you're here

- `.gitignore` excludes `.env`, any raw WRDS-derived data files, and any
  other credential or licensed-data file your project touches.
- If your pipeline used a WRDS Duo/SSH tunnel, confirm it is closed
  (run `bash tunnel_down.sh`, then `bash tunnel_status.sh` to check). A tunnel left running alongside an active
  agent session is one of the problems this audit is meant to catch before
  it leads to a real exposure.
