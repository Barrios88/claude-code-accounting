# Git as the Research Operating System — One-Page Handout

You do not need a semester of version control theory. You need five
commands and one habit. This page is everything Module 5 asks you to know
about git — everything else in a normal git workflow (branches, merges,
rebasing) is real, useful, and out of scope for this course.

## The one habit

**Tell Claude, at the very start of any project, to track everything in
git.** One sentence in your opening prompt is enough — something like "Set
up a git repository for this project and commit at every meaningful
checkpoint, with messages that say why, not just what." It does this
happily; treat it as a standing instruction for every project, not a one-time setup chore.

## The five commands

**1. `git init`** — turn a folder into a repository. Run once, at the
start of a project, before anything else happens in it.

**2. `git add -A && git commit -m "message"`** — the checkpoint. Snapshot
everything as of right now, with a message that explains *why* the change
was made, not just what changed. This is the single most important habit
on this page: commit at every real milestone (download script done, data
cleaned, figure produced), not just once at the end.

**3. `git log --oneline`** — the history. A short, readable list of every
checkpoint, in order. If you can't tell a coherent story by reading this
list top to bottom, your commits are too coarse.

**4. `git diff HEAD~1`** — the review unit. Shows exactly what changed in
the most recent commit — a bounded, readable diff instead of the entire
codebase. This is what makes an agent-produced pipeline reviewable: you
are never asked to review 800 lines at once, only the diff for one commit
at a time.

**5. `git push` / `git pull`** — sync with a remote (GitHub or similar), so
a coauthor, an RA, or a future you on a different machine sees the same
history. Push after a session's checkpoints are committed; pull before
starting a new session on a project someone else may have touched.

## `.gitignore` starter

Create this file at your project root, before your first commit if
possible — anything matching these patterns never gets tracked in the
first place, which is easier than removing something after the fact.

```gitignore
# Credentials — never commit these
.env
.env.*
# a project-scope MCP config can hold passwords
.mcp.json
*.pem
*_key
secrets.*

# Data — raw or licensed data usually doesn't belong in git
data/raw/
*.dta
*.csv
*.parquet

# OS / editor noise
.DS_Store
*.pyc
__pycache__/
.ipynb_checkpoints/
```

Adjust the data-file patterns to your project — the point is deciding on
purpose what's excluded, not blindly copying this list. If a small,
clearly non-sensitive `.csv` (a lookup table, not raw licensed data) should
be tracked, add an explicit exception rather than dropping the whole rule.

## Rollback recipe

The whole reason Auto mode is comfortable rather than reckless is that any
single bad change is one command away from undone — provided you commit
often enough that "one commit" is actually a small, recent change.

**Undo uncommitted changes** (agent edited a file you haven't committed
yet, and you want it back exactly as it was at the last commit):

```bash
git checkout -- <filename>
```

**Undo the most recent commit entirely** (destructive — discards the
commit and its changes):

```bash
git reset --hard HEAD~1
```

**Undo the most recent commit non-destructively** (creates a new commit
that reverses it, keeping the history intact — safer if you're not sure):

```bash
git revert HEAD
```

The worst thing an over-eager agent can do to your git-tracked work is
something you can roll back in seconds with one of the three commands
above. That is the whole safety argument for running in Auto mode instead
of Manual: the net is git, not per-action approval.

## The one line worth remembering

**A commit is the unit of verification.** You cannot review an entire
pipeline at once, and you shouldn't try. You can review one 12-line diff,
every time, without it becoming a chore you skip — which is the only kind
of review that actually happens consistently.
