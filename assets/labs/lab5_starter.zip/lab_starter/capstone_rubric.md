# Module 5 Capstone Rubric

Self-graded, pass/fail, as in every other lab in this course. Mark each line
pass or fail based on what is in your repository, not what you intended to
do. The instructor spot-checks three or four projects live in the debrief.
For at least one of them, the spot-check is the DECISIONS.md-against-commits
exercise below, run on your repo with no preparation, in front of the room.
Mark a line "pass" only if it would hold up under that check.

The requirements here match the rubric on the Module 5 lab page.

The rubric has four sections. The fourth is a stretch, not a requirement.

## Reproducibility

- [ ] The pipeline reruns start-to-finish from your README's instructions
      alone, in a clean clone of the repository (a fresh folder, not your
      working directory). No step may depend on something you remember
      that the README doesn't say.
- [ ] Git history shows meaningful commits at every real checkpoint
      (download, clean, measure, figure/table), each with a message that
      says *why*, not just *what*. One giant commit for the whole pipeline
      does not pass.

## Verification

- [ ] `DECISIONS.md`, `LOG.md`, and a sample-attrition table are all
      present, and you have checked them against the commit history
      instead of assuming they are accurate. Pick one specific claim from
      `DECISIONS.md`, find the commit (or commits) it should correspond
      to, and write down whether the diff supports the claim.

      Claim checked (copy the exact DECISIONS.md line):
      _________________________________________________________________

      Commit(s) it should correspond to:
      _________________________________________________________________

      Does the diff support the claim? Y / N. If N, note what's missing:
      _________________________________________________________________

- [ ] Two sanity checks are recorded with sources:

      Benchmark comparison (a number checked against something Claude
      didn't touch, plus the source):
      _________________________________________________________________

      Plausibility check (does the pattern make sense given what you know
      about the setting):
      _________________________________________________________________

- [ ] One number is traced end-to-end: raw data → script that computes it
      → `results.tex` → rendered output, with nothing typed by hand
      anywhere along that chain.

      Number traced: ___________________________________________________

      File path at each stage: _________________________________________

## Hygiene

- [ ] Both credential-audit commands run against this repository, with
      both outputs pasted below. Describing them as "clean" is not enough;
      paste the output.

      `git log --all --full-history -- .env` output:
      _________________________________________________________________

      `grep -r "<CREDENTIAL_NAME>" .` output (one search for each
      credential name your project uses):
      _________________________________________________________________

- [ ] `.gitignore` is correct: credentials, raw licensed data, and any
      WRDS-derived files are excluded, and a `git log --all -- .env`-style
      check confirms none of them were ever committed.
- [ ] If your pipeline used WRDS, you have confirmed the Duo/SSH tunnel is
      closed.
- [ ] One banal writing artifact was delegated to Claude (for example, a
      variable-definition table generated directly from your metadata
      table), and one meaningful artifact was written by hand: a
      three-sentence note stating your pipeline's contribution or a
      specific limitation, in your own words, that you could defend
      without the document in front of you.

## Environment (stretch)

- [ ] Rerun the pipeline, or a meaningful part of it, inside
      `claude-container` or `agent-safehouse`, and paste the output showing
      blocked access: the command you ran that should fail outside the
      mounted project folder, and the "operation not permitted"-style
      output confirming it did.

## If any box is unchecked

Don't erase the box. Note what is blocking it and bring it to the debrief,
or flag it on your exit ticket. An honestly unchecked box is more useful to
the instructor than one checked out of habit. This is the point of the
false-DECISIONS.md story from this morning: documentation that looks
complete has not necessarily been verified.
