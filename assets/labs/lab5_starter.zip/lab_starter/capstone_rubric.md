# Module 5 Capstone Rubric

Self-graded, pass/fail, as in every other lab in this course. Mark each line
pass or fail based on what is in your repository, not what you intended to
do. Then spot-check yourself: open `DECISIONS.md`, take the third entry (not
the one you already know holds), and check it against its commit in under
five minutes, with no preparation. If a colleague can look at your repo, let
them pick the entry. When the course runs with a group, the instructor also
spot-checks three or four projects live in the debrief. Mark a line "pass"
only if it would hold up under that check.

The requirements here match the rubric on the Module 5 lab page.

The rubric has four sections. The fourth is a stretch, not a requirement.

## Reproducibility

- [ ] The pipeline reruns start-to-finish from your README's instructions
      alone, in a clean clone of the repository (a fresh folder, not your
      working directory). No step may depend on something you remember
      that the README doesn't say.
- [ ] Git history shows meaningful commits at every real checkpoint
      (download, clean, measure, figure/table), each with a message that
      says *why*, not just *what*. One giant commit for the whole pipeline
      does not pass.

## Verification

- [ ] `DECISIONS.md`, `LOG.md`, and a sample-attrition table are all
      present, and you have checked them against the commit history
      instead of assuming they are accurate. Pick one specific claim from
      `DECISIONS.md`, find the commit (or commits) it should correspond
      to, and write down whether the diff supports the claim.

      Claim checked (copy the exact DECISIONS.md line):
      _________________________________________________________________

      Commit(s) it should correspond to:
      _________________________________________________________________

      Does the diff support the claim? Y / N. If N, note what's missing:
      _________________________________________________________________

- [ ] Two sanity checks are recorded with sources:

      Benchmark comparison (a number checked against something Claude
      didn't touch, plus the source):
      _________________________________________________________________

      Plausibility check (does the pattern make sense given what you know
      about the setting):
      _________________________________________________________________

- [ ] One number is traced end-to-end: raw data → script that computes it
      → `results.tex` → rendered output, with nothing typed by hand
      anywhere along that chain.

      Number traced: ___________________________________________________

      File path at each stage: _________________________________________

## Hygiene

- [ ] Both credential-audit checks from `audit_commands.md` run against
      this repository, with both outputs pasted below. Both come back
      empty, or the credential has been changed and removed from history.
      Describing them as "clean" is not enough; paste the output.

      Check 1, `git log --all --full-history --oneline -- '*.env' '*.env.*' '.mcp.json'`:
      _________________________________________________________________

      Check 2, the password search (`git log --all --oneline -S"$WRDS_PASSWORD"`
      and `git grep -l -F --untracked -e "$WRDS_PASSWORD"`), repeated for
      each other secret your project uses:
      _________________________________________________________________

- [ ] `.gitignore` is correct: credentials, raw licensed data, and any
      WRDS-derived files are excluded, and none of them was ever committed.

      `git log --all --full-history --oneline -- 'data/raw/*' '*.parquet' '*.dta' '*.csv'`
      output (adjust the paths to your project):
      _________________________________________________________________
- [ ] If your pipeline used WRDS, you have confirmed the Duo/SSH tunnel is
      closed.
- [ ] One banal writing artifact was delegated to Claude (for example, a
      variable-definition table generated directly from your metadata
      table), and one meaningful artifact was written by hand: a
      three-sentence note stating your pipeline's contribution or a
      specific limitation, in your own words, that you could defend
      without the document in front of you.

## Environment (stretch)

- [ ] Rerun the pipeline, or a meaningful part of it, inside a Docker dev
      container, `agent-safehouse` or Claude Code's built-in `/sandbox`,
      and paste the output showing blocked access: the command you ran
      that should fail outside the project folder, and the output
      confirming it did ("Operation not permitted", or "No such file or
      directory" in a dev container; see `container_quickstart.md`).

## If any box is unchecked

Don't erase the box. Note what is blocking it in your lab notes, or flag it
on your exit ticket. An honestly unchecked box tells you more than one
checked out of habit. This is the point of the false-DECISIONS.md story on
the module page: documentation that looks complete has not necessarily been
verified.
