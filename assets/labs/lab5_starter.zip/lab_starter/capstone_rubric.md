# Day 5 Capstone Rubric

Self-graded, pass/fail, same discipline as every other lab this week. The
instructor spot-checks 3–4 projects live in the debrief — for at least one,
that spot-check is the DECISIONS.md-against-commits exercise below, run cold
in front of the room. A line marked "pass" here should survive that.

This text is kept identical to the rubric on `website/labs/day5.qmd` — if you
edit one copy, edit both.

## Reproducibility

- [ ] The pipeline reruns start-to-finish from your README's instructions
      alone, in a clean clone of the repository (a fresh folder, not your
      working directory) — no step that only works because you remember
      something the README doesn't say.
- [ ] Git history shows meaningful commits at every real checkpoint
      (download, clean, measure, figure/table), each with a message that
      says *why*, not just *what* — not one giant commit that reads as a
      single undifferentiated blob.

## Verification

- [ ] `DECISIONS.md`, `LOG.md`, and a sample-attrition table are all
      present, and you have cross-checked them against the commit history
      rather than taken them on faith.

      Claim checked (copy the exact DECISIONS.md line):
      _________________________________________________________________

      Commit(s) it should correspond to:
      _________________________________________________________________

      Does the diff actually support the claim? Y / N — if N, note what's
      missing:
      _________________________________________________________________

- [ ] Two sanity checks are recorded with sources:

      Benchmark comparison (number + source Claude didn't touch):
      _________________________________________________________________

      Plausibility check (does the pattern make sense given the setting):
      _________________________________________________________________

- [ ] One number is traced end-to-end: raw data → script that computes it
      → `results.tex` → rendered output, zero hand-typing anywhere.

      Number traced: ___________________________________________________

      File path at each stage: _________________________________________

## Hygiene

- [ ] Both credential-audit commands run against this repository, outputs
      pasted below (not just described as "clean"):

      `git log --all --full-history -- .env` output:
      _________________________________________________________________

      `grep -r "<CREDENTIAL_NAME>" .` output:
      _________________________________________________________________

- [ ] `.gitignore` is correct — credentials, raw licensed data, and any
      WRDS-derived files excluded, and confirmed never committed.
- [ ] If your pipeline used WRDS, the Duo/SSH tunnel is confirmed down.
- [ ] One banal writing artifact was delegated to Claude (e.g., a
      variable-definition table generated from your metadata table), and
      one meaningful artifact was written by hand: a three-sentence
      contribution or limitations note you could defend without the
      document in front of you.

## Environment (stretch)

- [ ] Rerun the pipeline — or a meaningful slice of it — inside
      `claude-container` or `agent-safehouse`, and paste the blocked-access
      proof: the command that should fail outside the mounted project
      folder, and the "operation not permitted"-style output confirming it
      did.

## If any box is unchecked

Don't erase the box — note what's blocking it and bring it to the debrief
or flag it on your exit ticket. An honestly unchecked box is more useful to
the instructor than one checked out of habit — and this is exactly the
lesson of the false-DECISIONS.md story from this morning: documentation
that looks complete is not the same as documentation that's verified.
