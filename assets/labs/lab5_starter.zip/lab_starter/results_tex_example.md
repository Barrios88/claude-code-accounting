# The No-Hand-Typed-Numbers Pattern — Worked Example

A small, concrete version of the `results.tex` / `\input{}` pattern from
this morning's lecture. A number that appears in a paper should trace back,
in one step, to the script that computed it. No one should type it into the
manuscript by hand.

Use this as the model for your own "trace one number end-to-end" rubric
item. It doesn't need to be this regression, just the same chain:
raw data → script → `results.tex` → `\input{}` in the paper.

---

## Step 1: the script that computes the number

`compute_leverage_reg.do` (Stata version):

```stata
* compute_leverage_reg.do
use firm_year_panel.dta, clear

reg lev roa size mve i.fyear, cluster(gvkey)

* Write the coefficient of interest and its SE to a .tex fragment,
* not to the screen only.
file open results using "results/table2_main.tex", write replace
file write results "\newcommand{\betaLevRoa}{" %5.3f (_b[roa]) "}" _n
file write results "\newcommand{\seLevRoa}{" %5.3f (_se[roa]) "}" _n
file write results "\newcommand{\nObs}{" (e(N)) "}" _n
file close results
```

Equivalent Python version (`compute_leverage_reg.py`, if your pipeline is
Python/statsmodels-based):

```python
# compute_leverage_reg.py
import pandas as pd
import statsmodels.formula.api as smf

df = pd.read_parquet("firm_year_panel.parquet")
model = smf.ols("lev ~ roa + size + mve + C(fyear)", data=df).fit(
    cov_type="cluster", cov_kwds={"groups": df["gvkey"]}
)

beta = model.params["roa"]
se = model.bse["roa"]
n_obs = int(model.nobs)

with open("results/table2_main.tex", "w") as f:
    f.write(f"\\newcommand{{\\betaLevRoa}}{{{beta:.3f}}}\n")
    f.write(f"\\newcommand{{\\seLevRoa}}{{{se:.3f}}}\n")
    f.write(f"\\newcommand{{\\nObs}}{{{n_obs}}}\n")
```

Either way, running this script is what produces `results/table2_main.tex`.
No person handles the number at any point.

## Step 2: the generated file

`results/table2_main.tex` (generated, never hand-edited):

```latex
\newcommand{\betaLevRoa}{-0.184}
\newcommand{\seLevRoa}{0.041}
\newcommand{\nObs}{6540}
```

## Step 3: the paper pulls it in

In the main paper's `.tex` source:

```latex
\input{results/table2_main.tex}

We find that a one-unit increase in ROA is associated with a
\betaLevRoa\ decline in book leverage (SE = \seLevRoa, $N = \nObs$).
```

When the paper compiles, LaTeX expands `\betaLevRoa`, `\seLevRoa`, and
`\nObs` to whatever `results/table2_main.tex` currently contains. Rerun
`compute_leverage_reg.do` (or `.py`) after a sample change or a filter fix,
and the paper's text updates the next time it compiles. At no step does
anyone copy a number out of a terminal into the draft.

## Why this matters more with an LLM in the loop

Without this pattern, if you ask an LLM to "write the results paragraph for
Table 2," it will often produce a fluent sentence with a plausible
coefficient in it. Nothing computed that number. The model predicted a
likely-looking value from the rest of the context. The `\input{}` pattern
rules this out: a number can enter the manuscript only by being generated
from the pipeline.

## Capstone application

For your "one number traced end-to-end" rubric line, pick one number that
appears (or should appear) in your Module 3 or Module 4 pipeline's output,
and set up this chain for it if it doesn't exist yet:
raw data → a named script that computes it → a `results.tex`-style file →
an `\input{}` (or equivalent) that pulls it into whatever document you're
using to report results. Write down the three file paths in your capstone
notes: the script, the generated fragment, and the file that reads it in.
