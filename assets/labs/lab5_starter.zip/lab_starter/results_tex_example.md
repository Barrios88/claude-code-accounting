# The No-Hand-Typed-Numbers Pattern — Worked Example

A tiny, concrete version of the `results.tex` / `\input{}` pattern from
this morning's lecture. The point: a number that appears in a paper should
be traceable, in one hop, to the script that computed it — never typed by
a person into the manuscript.

Use this as the shape for your own "trace one number end-to-end" rubric
item — it doesn't need to be this exact regression, just the same chain:
raw data → script → `results.tex` → `\input{}` in the paper.

---

## Step 1: the script that computes the number

`compute_leverage_reg.do` (Stata version):

```stata
* compute_leverage_reg.do
use firm_year_panel.dta, clear

reg lev roa size mve i.fyear, cluster(gvkey)

* Write the coefficient of interest and its SE to a .tex fragment,
* not to the screen only.
file open results using "results/table2_main.tex", write replace
file write results "\newcommand{\betaLevRoa}{" %5.3f (_b[roa]) "}" _n
file write results "\newcommand{\seLevRoa}{" %5.3f (_se[roa]) "}" _n
file write results "\newcommand{\nObs}{" (e(N)) "}" _n
file close results
```

Equivalent Python version (`compute_leverage_reg.py`, if your pipeline is
Python/statsmodels-based):

```python
# compute_leverage_reg.py
import pandas as pd
import statsmodels.formula.api as smf

df = pd.read_parquet("firm_year_panel.parquet")
model = smf.ols("lev ~ roa + size + mve + C(fyear)", data=df).fit(
    cov_type="cluster", cov_kwds={"groups": df["gvkey"]}
)

beta = model.params["roa"]
se = model.bse["roa"]
n_obs = int(model.nobs)

with open("results/table2_main.tex", "w") as f:
    f.write(f"\\newcommand{{\\betaLevRoa}}{{{beta:.3f}}}\n")
    f.write(f"\\newcommand{{\\seLevRoa}}{{{se:.3f}}}\n")
    f.write(f"\\newcommand{{\\nObs}}{{{n_obs}}}\n")
```

Either way, running this script is what produces `results/table2_main.tex`
— nothing about the number ever passes through a person's hands.

## Step 2: the generated file

`results/table2_main.tex` (generated, never hand-edited):

```latex
\newcommand{\betaLevRoa}{-0.184}
\newcommand{\seLevRoa}{0.041}
\newcommand{\nObs}{6540}
```

## Step 3: the paper pulls it in

In the main paper's `.tex` source:

```latex
\input{results/table2_main.tex}

We find that a one-unit increase in ROA is associated with a
\betaLevRoa\ decline in book leverage (SE = \seLevRoa, $N = \nObs$).
```

When the paper compiles, LaTeX expands `\betaLevRoa`, `\seLevRoa`, and
`\nObs` to whatever `results/table2_main.tex` currently contains. Rerun
`compute_leverage_reg.do` (or `.py`) after a sample change or a filter fix,
and the paper's text updates automatically the next time it compiles — no
step where anyone copies a number out of a terminal into the draft.

## Why this matters more, not less, with an LLM in the loop

Ask an LLM to "write the results paragraph for Table 2" without this
pattern in place, and it will often produce a fluent sentence with a
plausible-sounding coefficient in it — one that was never actually computed
by anything, just predicted as a likely-looking number given the rest of
the context. The `\input{}` pattern makes that failure structurally
impossible: there is no place in the writing process where a number can
enter the manuscript except by being generated from the pipeline itself.

## Capstone application

For your "one number traced end-to-end" rubric line, pick one number that
currently appears (or should appear) in your Module 3 or Module 4 pipeline's
output, and set up exactly this chain for it if it doesn't already exist:
raw data → a named script that computes it → a `results.tex`-style file →
an `\input{}` (or equivalent) that pulls it into whatever document you're
using to report results. Write down the three file paths in your capstone
notes — the script, the generated fragment, and the file that consumes it.
