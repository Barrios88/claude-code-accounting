# DECISIONS.md / LOG.md Templates

Request both of these in your **opening prompt**, before any analysis
runs. Do not add them afterward once something looks off. If you already
have versions of these from Module 2 or Module 4, use those. These
templates are for anyone hardening a pipeline that doesn't have them yet,
or who wants a cleaner version for the capstone.

As this morning's lecture showed, a `DECISIONS.md` tells you where to look.
It does not prove the work was done. You should be able to check every
specific claim in it against a commit. If you can't find the commit, the
claim isn't verified, however confident the prose sounds.

---

## `DECISIONS.md` template

```markdown
# DECISIONS.md

Every methodological choice in this pipeline, in the order it was made.
Each entry: what was decided, what alternative(s) were considered and
rejected, and a rough confidence level. If a later session revisits a
decision, add a new entry — don't edit history.

## <short decision title>
**Decision:** <what was chosen>
**Alternatives considered:** <what else was possible, and why not>
**Confidence:** high / medium / low
**Commit(s):** <the commit hash(es) where this was actually implemented —
fill this in yourself after checking; do not trust an LLM-authored entry
that doesn't cite one>

---
```

**Capstone-specific addition:** for at least one entry, add a `Verified:`
line stating whether you personally checked the entry against the commit
history, and what you found. The rubric's Verification section asks for
this line, so write it out rather than leaving verification implied.

---

## `LOG.md` template

```markdown
# LOG.md

A plain-language narrative of this project, written so a coauthor who has
never seen the code could follow what happened and why, in order.

## Session: <date>
- Started with: <what existed at the start of this session>
- Did: <what was built or changed, in plain language, not code>
- Found: <anything unexpected — an error, a surprising row count, a
  pattern worth flagging>
- Ended with: <state at the end of the session; what's left>
```

---

## Sample-attrition table template

Print this at every stage where your sample size changes, not just at
the end. A final N on its own tells a reader nothing about where rows were
lost.

```
Stage                          N        Dropped   Reason
------------------------------  -------  --------  --------------------------------
Raw filings/observations        12,450   —         starting universe
After form-type filter          8,102    4,348     non-10-K/non-funda records removed
After date-range filter         6,890    1,212     outside sample window
After missing-key filter        6,540    350       missing gvkey/CIK or period
After winsorization             6,540    0         no rows dropped, values capped
Final analysis sample           6,540    —         —
```

Adapt the stage names to your pipeline (EDGAR extraction stages look
different from a `funda` pull), but keep the shape: a running N, what
changed at each step, and a one-line reason a stranger could understand
without reading the filter code.
