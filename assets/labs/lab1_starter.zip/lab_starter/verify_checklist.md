# Module 1 Verify Checklist

Self-graded, pass/fail. Work through every line before you consider the lab
complete. The instructor will spot-check a sample, not grade every box. What
counts is your own honest sign-off, the same habit you will use on every lab
in this course.

- [ ] `claude` launches in a fresh terminal, and `CLAUDE.md` loads in a new
      session: you asked what the project's conventions are, and the answer
      matched what you wrote.

- [ ] The task ran from a *named script* (e.g., `count_forms.py`), not from
      output pasted into the chat.

- [ ] At least one output number is checked against a source Claude did not
      touch. Write down what you checked and where. One reasonable check:
      compare your 10-K count for the quarter with SEC EDGAR's own filing
      search, filtered to the same form type and date range.

      Number checked: ______________________________________________

      Checked against: _____________________________________________

- [ ] `prompts_tried.md` contains at least one real vague-to-specific
      prompt rewrite from your own session (not copied from the module
      page). This applies whatever tier you chose.

- [ ] No credentials of any kind appear anywhere in `~/lab1/`. This lab
      uses only public data, so this box should be easy to tick. Check it
      anyway, to build the habit.

## If any box is unchecked

Do not erase the box. Note what is blocking it and bring it to the debrief,
or flag it on your exit ticket. An honestly unchecked box tells the
instructor more than a box checked out of habit.
