# Module 1 Verify Checklist

Self-graded, pass/fail. Work through every line before you consider the lab
complete. The instructor will spot-check a sample of these, not grade each
box individually — the point is your own honest sign-off, the same
discipline you'll use on every lab this week.

- [ ] `claude` launches in a fresh terminal, and `CLAUDE.md` visibly loads
      in a new session — you asked what the project's conventions are, and
      the answer matched what you wrote.

- [ ] The task ran from a *named script* (e.g. `count_forms.py`), not from
      output typed or pasted directly into the chat.

- [ ] At least one output number is checked against a source Claude did not
      touch. Write the source here:

      Number checked: ______________________________________________

      Checked against: _____________________________________________

- [ ] `prompts_tried.md` contains at least one real vague-to-specific
      prompt rewrite from your own session today (not copied from the
      module page).

- [ ] No credentials of any kind appear anywhere in this project folder.
      (Today's lab uses only public data, so this should be trivially
      true — check anyway; it's the habit that matters, not today's risk.)

## If any box is unchecked

Don't erase the box — note what's blocking it and bring it to the debrief
or flag it on your exit ticket. An honestly unchecked box is more useful to
the instructor than a box checked out of habit.
