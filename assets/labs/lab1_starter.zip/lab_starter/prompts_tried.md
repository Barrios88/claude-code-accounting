# Prompts Tried — Module 1 Log

Keep a running log of the prompts you had to rewrite during today's lab, in
the order you tried them. This file is not meant to make you look good. It
is meant to build the habit of noticing a vague prompt *before* it costs you
several turns of back-and-forth, and to give you something concrete to bring
to the debrief.

Whatever tier you chose in Part C, log at least one real vague-to-specific
rewrite from your own session. The worked example below shows the format.
Replace it with your own; do not leave it as is.

---

## Worked example (for format reference — log your own below)

**Attempt 1 (vague):**
> "Look at the FSDS file and tell me about the filings."

**What happened:** Before doing anything, Claude asked which quarter, which
fields, and what "tell me about" meant. I spent a turn clarifying scope that
I should have specified up front.

**Attempt 2 (specific):**
> "Read `sub.txt` from the 2023Q4 FSDS extract. Count filings by form
> type (column `form`). Save the result as `form_counts.csv`, produced by
> a script named `count_forms.py`."

**What changed:** The second prompt names the exact file, the exact column,
the exact aggregation (count by form type), and the exact output, including
both the data file and the script name. Claude ran it immediately, with no
clarifying turn.

**Turns saved:** 1 clarifying round-trip avoided.

---

## Your log

### Attempt 1 (vague)

> <TODO: paste your first, vaguer prompt here>

**What happened:** <TODO>

### Attempt 2 (specific)

> <TODO: paste your rewritten prompt here>

**What changed:** <TODO — name which of the four components (file,
operation, aggregation, output) was missing the first time>

**Turns saved:** <TODO>

---

<!-- Add more attempt pairs below if you rewrote more than one prompt,
     including the Stretch-tier Esc redirect if you attempted it. -->
