# Prompts Tried — Module 1 Log

Keep a running log of prompts you had to rewrite during today's lab, in the
order you tried them. The point of this file is not to make you look good —
it's to build the habit of noticing when a prompt was too vague *before* it
costs you several turns of back-and-forth, and to give you something
concrete to bring to the debrief.

Log at least one real vague-to-specific rewrite from your own session in
Part C. The worked example below shows the format — replace it with your
own, don't just leave it as-is.

---

## Worked example (for format reference — log your own below)

**Attempt 1 (vague):**
> "Look at the FSDS file and tell me about the filings."

**What happened:** Claude asked which quarter, which fields, and what
"tell me about" meant before doing anything — burned a turn just
clarifying scope that I should have specified up front.

**Attempt 2 (specific):**
> "Read `sub.txt` from the 2023Q4 FSDS extract. Count filings by form
> type (column `form`). Save the result as `form_counts.csv`, produced by
> a script named `count_forms.py`."

**What changed:** Named the exact file, the exact column, the exact
aggregation (count by form type), and the exact output — both the data
file and the script name. No clarifying turn needed; it ran immediately.

**Turns saved:** 1 clarifying round-trip avoided.

---

## Your log

### Attempt 1 (vague)

> <TODO: paste your first, vaguer prompt here>

**What happened:** <TODO>

### Attempt 2 (specific)

> <TODO: paste your rewritten prompt here>

**What changed:** <TODO — name which of the four components (file,
operation, aggregation, output) was missing the first time>

**Turns saved:** <TODO>

---

<!-- Add additional attempt pairs below if you rewrote more than one prompt,
     including the Stretch-tier ESC redirect if you attempted it. -->
